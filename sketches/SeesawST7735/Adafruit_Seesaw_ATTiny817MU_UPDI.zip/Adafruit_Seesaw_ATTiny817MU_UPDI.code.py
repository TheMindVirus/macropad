# https://docs.circuitpython.org/en/latest/shared-bindings/busio/index.html

import board, busio, time

seesaw = busio.I2C(board.SCL, board.SDA)
seesaw.try_lock()

devices = seesaw.scan()
address = [hex(a) for a in devices]
print(address)

data = []
for i in devices:
    try:
        #buffer = bytearray()
        #seesaw.writeto(i, buffer)
        #time.sleep(0.010)
        buffer = bytearray()
        seesaw.readfrom_into(i, buffer)
        data.append(buffer)
    except:
        buffer = bytearray()
        data.append(buffer)
print(data)

seesaw.unlock()
seesaw.deinit()

# [73] = ['0x49'] (I2C Address)
# RuntimeError: No pull up found on SDA or SCL; check your wiring
# No Device Is Connected To Other StemmaQT Port, Unplug and Replug to Reset

# ['0x49']
# [bytearray(b'')]