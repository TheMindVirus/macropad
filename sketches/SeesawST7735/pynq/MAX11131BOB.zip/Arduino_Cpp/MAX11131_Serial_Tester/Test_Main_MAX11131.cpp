﻿// /*******************************************************************************
// * Copyright (C) 2019 Maxim Integrated Products, Inc., All Rights Reserved.
// *
// * Permission is hereby granted, free of charge, to any person obtaining a
// * copy of this software and associated documentation files (the "Software"),
// * to deal in the Software without restriction, including without limitation
// * the rights to use, copy, modify, merge, publish, distribute, sublicense,
// * and/or sell copies of the Software, and to permit persons to whom the
// * Software is furnished to do so, subject to the following conditions:
// *
// * The above copyright notice and this permission notice shall be included
// * in all copies or substantial portions of the Software.
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
// * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// * OTHER DEALINGS IN THE SOFTWARE.
// *
// * Except as contained in this notice, the name of Maxim Integrated
// * Products, Inc. shall not be used except as stated in the Maxim Integrated
// * Products, Inc. Branding Policy.
// *
// * The mere transfer of this software does not imply any licenses
// * of trade secrets, proprietary technology, copyrights, patents,
// * trademarks, maskwork rights, or any other form of intellectual
// * property whatsoever. Maxim Integrated Products, Inc. retains all
// * ownership rights.
// *******************************************************************************
// */
// example code includes
// standard include for target platform -- Platform_Include_Boilerplate
#include "Arduino.h"
// SPI interface
#include "SPI.h"
// end Platform_Include_Boilerplate
#include "MAX11131.h"
#include "CmdLine.h"

CmdLine cmdLine_serial(Serial, "Serial");

//--------------------------------------------------
#define DIAGNOSTIC_SERIAL_BAUDRATE 9600

//--------------------------------------------------
// analogReference(INTERNAL) // Internal=1.1V
//#define ATMEGA328_VREF_V (1.1)
// analogReference(DEFAULT) // Default=supply voltage?
//#define ATMEGA328_VREF_V (3.248)
float ATMEGA328_VREF_V=5.0;


// example code declare SPI interface
// global SPI uses conventional Arduino 10-pin header D11 D12 D13
// chip select is on Arduino 10-pin header D10
uint8_t spi_cs = 10; // Generic: Arduino 10-pin header D10

// example code declare GPIO interface pins
uint8_t CNVST_pin = 9; // Digital Trigger Input to MAX11131 device
// uint8_t REF_plus_pin = Px_x_PortName_To_Be_Determined; // Reference Input to MAX11131 device
// uint8_t REF_minus_slash_AIN15_pin = Px_x_PortName_To_Be_Determined; // Reference Input to MAX11131 device
uint8_t EOC_pin = 2; // Digital Event Output from MAX11131 device
// example code declare device instance
MAX11131 g_MAX11131_device(spi_cs, CNVST_pin, EOC_pin, MAX11131::MAX11131_IC);


#define HAS_digitalInOuts 1
#define HAS_analogIns 1
#define APPLICATION_MAX11131 1

//----------------------------------------
// Global SPI options
//
#ifndef HAS_SPI
#define HAS_SPI 1
#endif
#if HAS_SPI
#if defined (__AVR_ATmega328__) || defined (__AVR_ATmega328P__) || defined (__AVR_ATmega32U4__)
#include <SPI.h>
#endif
const int SPI_CS_Pin = 10;
const int SPI_MOSI_Pin = 11;
const int SPI_MISO_Pin = 12;
const int SPI_SCLK_Pin = 13;
// Default SPI clock is 2MHz (given 8MHz F_CPU)
  // see C:\Program Files (x86)\Arduino-1.6.0\hardware\arduino\avr\libraries\SPI\SPI.h
  // Before using SPI.transfer() or asserting chip select pins, SPI.beginTransaction is used to gain exclusive access to the SPI bus and configure the correct settings.
  // SPI.beginTransaction(SPISettings(uint32_t clock, uint8_t bitOrder, uint8_t dataMode));
  // After performing a group of transfers and releasing the chip select signal, SPI.endTransaction() allows others to access the SPI bus
  // SPI.endTransaction()
//#define SPI_SCLK_Hz 4000000 // 4MHz
#define SPI_SCLK_Hz 2000000 // 2MHz
//#define SPI_SCLK_Hz 1000000 // 1MHz
#define SPI_bitOrder MSBFIRST
//#define SPI_dataMode SPI_MODE0 // CPOL=0,CPHA=0: Rising Edge stable; SCLK idle Low
//#define SPI_dataMode SPI_MODE1 // CPOL=0,CPHA=1: Falling Edge stable; SCLK idle Low
//#define SPI_dataMode SPI_MODE2 // CPOL=1,CPHA=0: Falling Edge stable; SCLK idle High
#define SPI_dataMode SPI_MODE3 // CPOL=1,CPHA=1: Rising Edge stable; SCLK idle High
uint32_t g_SPI_SCLK_Hz = SPI_SCLK_Hz;
const long int limit_max_SPI_SCLK_Hz = F_CPU / 2; // 8MHz / 2 = 4MHz
const long int limit_min_SPI_SCLK_Hz = F_CPU / 128; // 8MHz / 128 = 62.5kHz
uint8_t g_SPI_dataMode = SPI_dataMode;
// VERIFY: SPI_SCLK_Hz can I run at a faster speed?
// VERIFY: parse new SPI settings parse_strCommandArgs() SCLK=1000000 CPOL=0 CPHA=0
#endif // SUPPORT_SPI

//----------------------------------------
// Global I2C options
//
#ifndef HAS_I2C
#define HAS_I2C 0
#endif


//--------------------------------------------------
void SelfTest(CmdLine & cmdLine)
{
    cmdLine.serial().println("test program not implemented yet");
}


//--------------------------------------------------
inline void print_command_prompt()
{
    cmdLine_serial.serial().print("\r\n> ");
}


//--------------------------------------------------
// Menu A) analogRead A0..7
// Menu A) with no argument: read all analog inputs
void MenuA_analogRead(int pinIndex)
{
  char strOutLineBuffer[16];
  
  int adcCode = analogRead(pinIndex); // analog input pins A0, A1, A2, A3, A4, A5; float voltage = analogRead(A0) * (vref / 1024.0)
  // VERIFY: BUGFIX Menu A) analogRead A0..7: adcVoltage = adcCode * ... not analogRead(A0) * ...
  float adcVoltage = adcCode * (ATMEGA328_VREF_V / 1024.0);
  Serial.print(pinIndex);
  Serial.print(F(" ADC="));
  Serial.print(adcCode);
  Serial.print("/1024 = ");
  //Serial.print(adcVoltage);
  // dtostrf width and precision: 3.3V / 1024 LSB = 0.00322265625 volts per LSB
  dtostrf(adcVoltage, 5, 3, strOutLineBuffer); // value, width, precision, char* buffer
  Serial.print(strOutLineBuffer);
  Serial.println("V");
}


//--------------------------------------------------
void pinsMonitor_submenu_onEOLcommandParser(CmdLine& cmdLine)
{
    // % diagnostic commands submenu
    // %Hpin -- digital output high
    // %Lpin -- digital output low
    // %?pin -- digital input
    // %A %Apin -- analog input
    // %Ppin df=xx -- pwm output
    // %Wpin -- measure high pulsewidth input in usec
    // %wpin -- measure low pulsewidth input in usec
    // %I... -- I2C diagnostics
    // %IP -- I2C probe
    // %IC scl=100khz ADDR=? -- I2C configure
    // %IW byte byte ... byte RD=? ADDR=0x -- write
    // %IR ADDR=? RD=? -- read
    // %I^ cmd=? -- i2c_smbus_read_word_data
    // %S... -- SPI diagnostics
    // %SC sclk=1Mhz -- SPI configure
    // %SW -- write (write and read)
    // %SR -- read (alias for %SW because SPI always write and read)
    // A-Z,a-z,0-9 reserved for application use
    //
    char strPinIndex[3];
    strPinIndex[0] = cmdLine[2];
    strPinIndex[1] = cmdLine[3];
    strPinIndex[2] = '\0';
    int pinIndex = strtoul(strPinIndex, NULL, 10);         // strtol(str, NULL, 10): get decimal value
    //cmdLine.serial().print(" pinIndex=%d ", pinIndex);
    //
    // get next character
    switch (cmdLine[1])
    {
#if HAS_digitalInOuts
    // %Hpin -- digital output high
        case 'H': case 'h':
        {
            // %Hpin -- digital output high
#if 1 // ARDUINO_STYLE
            pinMode(pinIndex, OUTPUT);             // digital pins 0, 1, 2, .. 13, analog input pins A0, A1, .. A5
            digitalWrite(pinIndex, HIGH);             // digital pins 0, 1, 2, .. 13, analog input pins A0, A1, .. A5
#else
            DigitalInOut& digitalInOutPin = find_digitalInOutPin(pinIndex);
            digitalInOutPin.output();
            digitalInOutPin.write(1);
#endif
            cmdLine.serial().print(F(" digitalInOutPin "));
            cmdLine.serial().print(pinIndex, DEC);
            cmdLine.serial().print(F(" Output High "));
        }
        break;
    // %Lpin -- digital output low
        case 'L': case 'l':
        {
            // %Lpin -- digital output low
#if 1 // ARDUINO_STYLE
            pinMode(pinIndex, OUTPUT);             // digital pins 0, 1, 2, .. 13, analog input pins A0, A1, .. A5
            digitalWrite(pinIndex, LOW);             // digital pins 0, 1, 2, .. 13, analog input pins A0, A1, .. A5
#else
            DigitalInOut& digitalInOutPin = find_digitalInOutPin(pinIndex);
            digitalInOutPin.output();
            digitalInOutPin.write(0);
#endif
            cmdLine.serial().print(F(" digitalInOutPin "));
            cmdLine.serial().print(pinIndex, DEC);
            cmdLine.serial().print(F(" Output Low "));
        }
        break;
    // %?pin -- digital input
        case '?':
        {
            // %?pin -- digital input
#if 1 // ARDUINO_STYLE
            pinMode(pinIndex, INPUT);             // digital pins 0, 1, 2, .. 13, analog input pins A0, A1, .. A5
#else
            DigitalInOut& digitalInOutPin = find_digitalInOutPin(pinIndex);
            digitalInOutPin.input();
#endif
            cmdLine.serial().print(F(" digitalInOutPin "));
            cmdLine.serial().print(pinIndex, DEC);
            cmdLine.serial().print(F(" Input "));
#if 1 // ARDUINO_STYLE
            int value = digitalRead(pinIndex);
#else
            int value = digitalInOutPin.read();
#endif
            cmdLine.serial().print(value, DEC);
            cmdLine.serial().print(F(" "));
        }
        break;
#endif // HAS_digitalInOuts
        //
    // %A %Apin -- analog input
#if HAS_analogIns
        case 'A': case 'a':
        {
            // %A %Apin -- analog input
            cmdLine.parse_float("vref", ATMEGA328_VREF_V); // %A vref=5.0
            // full scale depends on previous analogReference(DEFAULT | INTERNAL | EXTERNAL)
            // Arduino UNO: Default=5V, Internal=1.1V, External=AREF pin <5V
            // get pinIndex from strCommandArgs
            if (cmdLine[2] == '\0') {
                // Menu A) with no argument: read all analog inputs
                for (pinIndex = 0; pinIndex < 8; pinIndex++) {
                    MenuA_analogRead(pinIndex);
                }
            } else {
                // pinIndex = strtoul(strCommandArgs.c_str(), NULL, 10); // strtol(str, NULL, 10): get decimal value
                MenuA_analogRead(pinIndex);
            }
        }
        break;
#endif // HAS_analogIns
        //
    // %Ppin df=xx -- pwm output
        //
    // %Wpin -- measure high pulsewidth input in usec
    // %wpin -- measure low pulsewidth input in usec
        //
    // %I... -- I2C diagnostics
    // %IP -- I2C probe
    // %IC scl=100khz ADDR=? -- I2C configure
    // %IW byte byte ... byte RD=? ADDR=0x -- write
    // %IR ADDR=? RD=? -- read
    // %I^ cmd=? -- i2c_smbus_read_word_data
#if HAS_I2C // HAS_I2C
        case 'I': case 'i':
            // %I... -- I2C diagnostics
            // %IP -- I2C probe
            // %IC scl=100khz ADDR=? -- I2C configure
            // %IW byte byte ... byte RD=? ADDR=0x -- write
            // %IR ADDR=? RD=? -- read
            // %I^ cmd=? -- i2c_smbus_read_word_data
            // get next character
            // TODO: parse cmdLine arg (ADDR=\d+)? --> g_I2C_deviceAddress7
            cmdLine.parse_byte_hex("ADDR", g_I2C_deviceAddress7);
            // TODO: parse cmdLine arg (RD=\d)? --> g_I2C_read_count
            g_I2C_read_count = 0;         // read count must be reset every command
            cmdLine.parse_byte_dec("RD", g_I2C_read_count);
            // TODO: parse cmdLine arg (CMD=\d)? --> g_I2C_command_regAddress
            cmdLine.parse_byte_hex("CMD", g_I2C_command_regAddress);
            switch (cmdLine[2])
            {
                case 'P': case 'p':
                {
                    // %IP -- I2C probe
                    HuntAttachedI2CDevices(cmdLine, 0x03, 0x77);
                }
                break;
                case 'C': case 'c':
                {
                    bool isUpdatedI2CConfig = false;
                    // %IC scl=100khz ADDR=? -- I2C configure
                    // parse cmdLine arg (SCL=\d+(kHZ|MHZ)?)? --> g_I2C_SCL_Hz
                    if (cmdLine.parse_frequency_Hz("SCL", g_I2C_SCL_Hz))
                    {
                        isUpdatedI2CConfig = true;
                        // TODO1: validate g_I2C_SCL_Hz against system clock frequency F_CPU
                        if (g_I2C_SCL_Hz > limit_max_I2C_SCL_Hz)
                        {
                            g_I2C_SCL_Hz = limit_max_I2C_SCL_Hz;
                        }
                        if (g_I2C_SCL_Hz < limit_min_I2C_SCL_Hz)
                        {
                            g_I2C_SCL_Hz = limit_min_I2C_SCL_Hz;
                        }
                    }
                    if (isUpdatedI2CConfig)
                    {
                        // declare in narrower scope: MAX32625MBED I2C i2cMaster(...)
                        I2C i2cMaster(I2C0_SDA, I2C0_SCL);             // sda scl TARGET_MAX32635MBED: P1_6, P1_7 Arduino 10-pin header
                        i2cMaster.frequency(g_I2C_SCL_Hz);
                        i2cMaster.start();
                        i2cMaster.stop();
                        i2cMaster.frequency(g_I2C_SCL_Hz);
                        cmdLine.serial().printf(
                            "\r\n %IC ADDR=0x%2.2x=(0x%2.2x>>1) SCL=%d=%1.3fkHz -- I2C config",
                            g_I2C_deviceAddress7, (g_I2C_deviceAddress7 << 1), g_I2C_SCL_Hz,
                            (g_I2C_SCL_Hz / 1000.));
                        i2cMaster.start();
                        i2cMaster.stop();
                    }
                }
                break;
                case 'W': case 'w':
                {
                    // declare in narrower scope: MAX32625MBED I2C i2cMaster(...)
                    I2C i2cMaster(I2C0_SDA, I2C0_SCL);             // sda scl TARGET_MAX32635MBED: P1_6, P1_7 Arduino 10-pin header
                    i2cMaster.frequency(g_I2C_SCL_Hz);
                    // %IW byte byte ... byte RD=? ADDR=0x -- write
                    // parse cmdLine byte list --> int byteCount; int mosiData[MAX_SPI_BYTE_COUNT];
                    #define MAX_I2C_BYTE_COUNT 32
                    size_t byteCount = byteCount;
                    static char mosiData[MAX_I2C_BYTE_COUNT];
                    static char misoData[MAX_I2C_BYTE_COUNT];
                    if (cmdLine.parse_byteCount_byteList_hex(byteCount, mosiData,
                                                             MAX_I2C_BYTE_COUNT))
                    {
                        // hex dump mosiData[0..byteCount-1]
                        cmdLine.serial().printf(
                            "\r\nADDR=0x%2.2x=(0x%2.2x>>1) byteCount:%d RD=%d\r\nI2C MOSI->",
                            g_I2C_deviceAddress7,
                            (g_I2C_deviceAddress7 << 1), byteCount, g_I2C_read_count);
                        for (unsigned int byteIndex = 0; byteIndex < byteCount; byteIndex++)
                        {
                            cmdLine.serial().printf(" 0x%2.2X", mosiData[byteIndex]);
                        }
                        //
                        // TODO: i2c transfer
                        //const int addr7bit = 0x48;      // 7 bit I2C address
                        //const int addr8bit = 0x48 << 1; // 8bit I2C address, 0x90
                        // /* int  */   i2cMaster.read (int addr8bit, char *data, int length, bool repeated=false) // Read from an I2C slave.
                        // /* int  */   i2cMaster.read (int ack) // Read a single byte from the I2C bus.
                        // /* int  */   i2cMaster.write (int addr8bit, const char *data, int length, bool repeated=false) // Write to an I2C slave.
                        // /* int  */   i2cMaster.write (int data) // Write single byte out on the I2C bus.
                        // /* void */   i2cMaster.start (void) // Creates a start condition on the I2C bus.
                        // /* void */   i2cMaster.stop (void) // Creates a stop condition on the I2C bus.
                        // /* int */    i2cMaster.transfer (int addr8bit, const char *tx_buffer, int tx_length, char *rx_buffer, int rx_length, const event_callback_t &callback, int event=I2C_EVENT_TRANSFER_COMPLETE, bool repeated=false) // Start nonblocking I2C transfer. More...
                        // /* void */   i2cMaster.abort_transfer () // Abort the ongoing I2C transfer. More...
                        const int addr8bit = g_I2C_deviceAddress7 << 1;             // 8bit I2C address, 0x90
                        unsigned int misoLength = 0;
                        bool repeated = (g_I2C_read_count > 0);
                        //
                        int writeStatus = i2cMaster.write (addr8bit, mosiData, byteCount, repeated);
                        switch (writeStatus)
                        {
                            case 0: cmdLine.serial().print(F(" ack ")); break;
                            case 1: cmdLine.serial().print(F(" nack ")); break;
                            default: cmdLine.serial().printf(" {writeStatus 0x%2.2X} ",
                                                             writeStatus);
                        }
                        if (repeated)
                        {
                            int readStatus =
                                i2cMaster.read (addr8bit, misoData, g_I2C_read_count, false);
                            switch (readStatus)
                            {
                                case 1: cmdLine.serial().print(F(" nack ")); break;
                                case 0: cmdLine.serial().print(F(" ack ")); break;
                                default: cmdLine.serial().printf(" {readStatus 0x%2.2X} ",
                                                                 readStatus);
                            }
                        }
                        //
                        if (misoLength > 0)
                        {
                            // hex dump misoData[0..byteCount-1]
                            cmdLine.serial().print(F("  MISO<-"));
                            for (unsigned int byteIndex = 0; byteIndex < g_I2C_read_count;
                                 byteIndex++)
                            {
                                cmdLine.serial().printf(" 0x%2.2X", misoData[byteIndex]);
                            }
                        }
                        cmdLine.serial().print(F(" "));
                    }
                }
                break;
                case 'R': case 'r':
                {
                    // declare in narrower scope: MAX32625MBED I2C i2cMaster(...)
                    I2C i2cMaster(I2C0_SDA, I2C0_SCL);             // sda scl TARGET_MAX32635MBED: P1_6, P1_7 Arduino 10-pin header
                    i2cMaster.frequency(g_I2C_SCL_Hz);
                    // %IR ADDR=? RD=? -- read
                    // TODO: i2c transfer
                    //const int addr7bit = 0x48;      // 7 bit I2C address
                    //const int addr8bit = 0x48 << 1; // 8bit I2C address, 0x90
                    // /* int  */   i2cMaster.read (int addr8bit, char *data, int length, bool repeated=false) // Read from an I2C slave.
                    // /* int  */   i2cMaster.read (int ack) // Read a single byte from the I2C bus.
                    // /* int  */   i2cMaster.write (int addr8bit, const char *data, int length, bool repeated=false) // Write to an I2C slave.
                    // /* int  */   i2cMaster.write (int data) // Write single byte out on the I2C bus.
                    // /* void */   i2cMaster.start (void) // Creates a start condition on the I2C bus.
                    // /* void */   i2cMaster.stop (void) // Creates a stop condition on the I2C bus.
                    // /* int */    i2cMaster.transfer (int addr8bit, const char *tx_buffer, int tx_length, char *rx_buffer, int rx_length, const event_callback_t &callback, int event=I2C_EVENT_TRANSFER_COMPLETE, bool repeated=false) // Start nonblocking I2C transfer. More...
                    // /* void */   i2cMaster.abort_transfer () // Abort the ongoing I2C transfer. More...
                }
                break;
                case '^':
                {
                    // declare in narrower scope: MAX32625MBED I2C i2cMaster(...)
                    I2C i2cMaster(I2C0_SDA, I2C0_SCL);             // sda scl TARGET_MAX32635MBED: P1_6, P1_7 Arduino 10-pin header
                    i2cMaster.frequency(g_I2C_SCL_Hz);
                    // %I^ cmd=? -- i2c_smbus_read_word_data
                    // TODO: i2c transfer
                    //const int addr7bit = 0x48;      // 7 bit I2C address
                    //const int addr8bit = 0x48 << 1; // 8bit I2C address, 0x90
                    // /* int  */   i2cMaster.read (int addr8bit, char *data, int length, bool repeated=false) // Read from an I2C slave.
                    // /* int  */   i2cMaster.read (int ack) // Read a single byte from the I2C bus.
                    // /* int  */   i2cMaster.write (int addr8bit, const char *data, int length, bool repeated=false) // Write to an I2C slave.
                    // /* int  */   i2cMaster.write (int data) // Write single byte out on the I2C bus.
                    // /* void */   i2cMaster.start (void) // Creates a start condition on the I2C bus.
                    // /* void */   i2cMaster.stop (void) // Creates a stop condition on the I2C bus.
                    // /* int */    i2cMaster.transfer (int addr8bit, const char *tx_buffer, int tx_length, char *rx_buffer, int rx_length, const event_callback_t &callback, int event=I2C_EVENT_TRANSFER_COMPLETE, bool repeated=false) // Start nonblocking I2C transfer. More...
                    // /* void */   i2cMaster.abort_transfer () // Abort the ongoing I2C transfer. More...
                }
                break;
            }         // switch(cmdLine[2])
            break;
#endif // HAS_I2C // HAS_I2C
        //
    // %S... -- SPI diagnostics
    // %SC sclk=1Mhz -- SPI configure
    // %SW -- write (write and read)
    // %SR -- read (alias for %SW because SPI always write and read)
#if HAS_SPI // SUPPORT_SPI
        case 'S': case 's':
        {
            // %S... -- SPI diagnostics
            // %SC sclk=1Mhz -- SPI configure
            // %SW -- write (write and read)
            // %SR -- read (alias for %SW because SPI always write and read)
            //
            // Process arguments SCLK=\d+(kHZ|MHZ) CPOL=\d CPHA=\d
            bool isUpdatedSPIConfig = false;
            // parse cmdLine arg (CPOL=\d)? --> g_SPI_dataMode | SPI_MODE2
            // parse cmdLine arg (CPHA=\d)? --> g_SPI_dataMode | SPI_MODE1
            if (cmdLine.parse_flag("CPOL", g_SPI_dataMode, SPI_MODE2))
            {
                isUpdatedSPIConfig = true;
            }
            if (cmdLine.parse_flag("CPHA", g_SPI_dataMode, SPI_MODE1))
            {
                isUpdatedSPIConfig = true;
            }
            // if (cmdLine.parse_flag("CS", g_SPI_cs_state, 1))
            // {
            //     isUpdatedSPIConfig = true;
            // }
            // parse cmdLine arg (SCLK=\d+(kHZ|MHZ)?)? --> g_SPI_SCLK_Hz
            if (cmdLine.parse_frequency_Hz("SCLK", g_SPI_SCLK_Hz))
            {
                isUpdatedSPIConfig = true;
                // TODO1: validate g_SPI_SCLK_Hz against system clock frequency F_CPU
                if (g_SPI_SCLK_Hz > limit_max_SPI_SCLK_Hz)
                {
                    g_SPI_SCLK_Hz = limit_max_SPI_SCLK_Hz;
                }
                if (g_SPI_SCLK_Hz < limit_min_SPI_SCLK_Hz)
                {
                    g_SPI_SCLK_Hz = limit_min_SPI_SCLK_Hz;
                }
            }
            // Update SPI configuration
            if (isUpdatedSPIConfig)
            {
                // %SC sclk=1Mhz -- SPI configure
                //~ spi_cs = g_SPI_cs_state;
                //spi.format(8,g_SPI_dataMode);             // int bits_must_be_8, int mode=0_3 CPOL=0,CPHA=0
                g_MAX11131_device.spi_frequency(g_SPI_SCLK_Hz);
                //
                double ideal_divisor = ((double)F_CPU) / g_SPI_SCLK_Hz;
                int actual_divisor = (int)(ideal_divisor + 0.0);             // frequency divisor truncate
                double actual_SCLK_Hz = F_CPU / actual_divisor;
                //
                // fixed: mbed-os-5.11: [Warning] format '%d' expects argument of type 'int', but argument 6 has type 'uint32_t {aka long unsigned int}' [-Wformat=]
                // cmdLine.serial().printf(
                //     "\r\n %SC CPOL=%d CPHA=%d CS=%d SCLK=%ld=%1.3fMHz (%1.1fMHz/%1.2f = actual %1.3fMHz) -- SPI config",
                //     ((g_SPI_dataMode & SPI_MODE2) ? 1 : 0),
                //     ((g_SPI_dataMode & SPI_MODE1) ? 1 : 0),
                //     g_SPI_cs_state,
                //     g_SPI_SCLK_Hz,
                //     (g_SPI_SCLK_Hz / 1000000.),
                //     ((double)(F_CPU / 1000000.)),
                //     ideal_divisor,
                //     (actual_SCLK_Hz / 1000000.)
                //     );
                Serial.print(F("%SC SCLK="));
                Serial.print(g_SPI_SCLK_Hz);
                if (g_SPI_SCLK_Hz >= 1000000) {
                  Serial.print(F("="));
                  Serial.print(g_SPI_SCLK_Hz / 1000000);
                  Serial.print(F("MHz"));
                }
                else if (g_SPI_SCLK_Hz >= 1000) {
                  Serial.print(F("="));
                  Serial.print(g_SPI_SCLK_Hz / 1000);
                  Serial.print(F("kHz"));
                }
                Serial.print(F(" CPOL="));
                // VERIFY: print CPOL=0 or 1 depending on g_SPI_dataMode & SPI_MODE2
                if (g_SPI_dataMode & SPI_MODE2) { Serial.print(1); } else {  Serial.print(0); }
                Serial.print(F(" CPHA="));
                // VERIFY: print CPHA=0 or 1 depending on g_SPI_dataMode & SPI_MODE1
                if (g_SPI_dataMode & SPI_MODE1) { Serial.print(1); } else {  Serial.print(0); }
                Serial.println();
            }
            // get next character
            switch (cmdLine[2])
            {
                case 'C': case 's':
                    // %SC sclk=1Mhz -- SPI configure
                    break;
                case 'W': case 'R': case 'w': case 'r':
                {
                    // %SW -- write (write and read)
                    // %SR -- read (alias for %SW because SPI always write and read)
                    // parse cmdLine byte list --> int byteCount; int mosiData[MAX_SPI_BYTE_COUNT];
                    #define MAX_SPI_BYTE_COUNT 32
                    size_t byteCount = byteCount;
                    static char mosiData[MAX_SPI_BYTE_COUNT];
                    static char misoData[MAX_SPI_BYTE_COUNT];
                    if (cmdLine.parse_byteCount_byteList_hex(byteCount, mosiData,
                                                             MAX_SPI_BYTE_COUNT))
                    {
                        // hex dump mosiData[0..byteCount-1]
                        cmdLine.serial().print(F("\r\nSPI"));
                        if (byteCount > 7) {
                            Serial.print(F("byteCount:"));
                            Serial.println(byteCount);
                        }
                        Serial.print(F("MOSI->"));
                        for (unsigned int byteIndex = 0; byteIndex < byteCount; byteIndex++)
                        {
                            Serial.print(F(" 0x"));
                            Serial.print((mosiData[byteIndex] & 0xFF), HEX);
                        }
                        //unsigned int numBytesTransferred =
                        //    spi.write(mosiData, byteCount, misoData, byteCount);
                        // SPI command CRASH after DL10 DI10
                        digitalWrite(SPI_CS_Pin, HIGH); // SPI CS inactive high
                        pinMode (SPI_CS_Pin, OUTPUT); // ensure SPI CS is driven output
                        digitalWrite(SPI_CS_Pin, LOW); // SPI CS active low
                        SPI.beginTransaction(SPISettings(g_SPI_SCLK_Hz, SPI_bitOrder, g_SPI_dataMode));
                        for (int byteIndex = 0; byteIndex < byteCount; byteIndex++)
                        {
                            // automated testing: SPI transfer sometimes messes up regression test capture?
                            misoData[byteIndex] = SPI.transfer(mosiData[byteIndex]);
                        }
                        SPI.endTransaction();
                        digitalWrite(SPI_CS_Pin, HIGH); // SPI CS inactive high
                        //spi_cs = 1;
                        // hex dump misoData[0..byteCount-1]
                        Serial.print(F("  MISO<-"));
                        for (int byteIndex = 0; byteIndex < byteCount; byteIndex++)
                        {
                          Serial.print(F(" 0x"));
                          Serial.print((misoData[byteIndex] & 0xFF), HEX);
                        }
                    }
                    Serial.println();
                }
                break;
            }             // switch(cmdLine[2])
        }             // case 'S': // %S... -- SPI diagnostics
        break;
#endif // HAS_SPI // SUPPORT_SPI
        //
    //
    // A-Z,a-z,0-9 reserved for application use
    } // switch(cmdLine[1])
} // end void pinsMonitor_submenu_onEOLcommandParser(CmdLine & cmdLine)


//--------------------------------------------------
void main_menu_status(CmdLine & cmdLine)
{
    cmdLine.serial().print(F("\r\nMain menu"));
    cmdLine.serial().print(F(" MAX11131 12-bit 3Msps 16-ch ADC"));
    //cmdLine.serial().print(" %s", TARGET_NAME);
    if (cmdLine.nameStr())
    {
        cmdLine.serial().print(F(" ["));
        cmdLine.serial().print(cmdLine.nameStr());
        cmdLine.serial().print(F("]"));
    }
#if HAS_BUTTON1_DEMO_INTERRUPT
    cmdLine.serial().print(F(" [Button1=DemoConfig1]"));
#endif
#if HAS_BUTTON2_DEMO_INTERRUPT
    cmdLine.serial().print(F(" [Button2=DemoConfig2]"));
#endif
#if HAS_BUTTON1_DEMO
    // print BUTTON1 status
    cmdLine.serial().print("\r\n BUTTON1 = %d", button1.read());
#endif
#if HAS_BUTTON2_DEMO
    // print BUTTON1 status
    cmdLine.serial().print("\r\n BUTTON2 = %d", button2.read());
#endif
    cmdLine.serial().print(F("\r\n ? -- help"));
}


//--------------------------------------------------
void main_menu_help(CmdLine & cmdLine)
{
    // ? -- help
    //~ cmdLine.serial().print(F("\r\nMenu:"));
    cmdLine.serial().print(F("\r\n # -- lines beginning with # are comments"));
    cmdLine.serial().print(F("\r\n . -- SelfTest"));
    //cmdLine.serial().print(F("\r\n ! -- Initial Configuration"));
    //
    // % standardize diagnostic commands
    // %Hpin -- digital output high
    // %Lpin -- digital output low
    // %?pin -- digital input
    // %A %Apin -- analog input
    // %Ppin df=xx -- pwm output
    // %Wpin -- measure high pulsewidth input in usec
    // %wpin -- measure low pulsewidth input in usec
    // %I... -- I2C diagnostics
    // %IP -- I2C probe
    // %IC scl=100khz ADDR=? -- I2C configure
    // %IW ADDR=? cmd=? data,data,data -- write
    // %IR ADDR=? RD=? -- read
    // %I^ cmd=? -- i2c_smbus_read_word_data
    // %S... -- SPI diagnostics
    // %SC sclk=1Mhz -- SPI configure
    // %SW -- write (write and read)
    // %SR -- read (alias for %SW because SPI always write and read)
    // A-Z,a-z,0-9 reserved for application use
    //
#if HAS_digitalInOuts
    // %Hpin -- digital output high
    // %Lpin -- digital output low
    // %?pin -- digital input
      cmdLine.serial().print(F("\r\n %Hn -- High Output Arduino D0..13, 14=A0..7"));
      cmdLine.serial().print(F("\r\n %Ln -- Low Output Arduino D0..13, 14=A0..7"));
      cmdLine.serial().print(F("\r\n %?n -- Input Arduino D0..13, 14=A0..7"));
#endif

#if HAS_analogIns
    // Menu A) analogRead A0..7
    // %A %Apin -- analog input
    // analogRead(pinIndex) // analog input pins A0, A1, A2, A3, A4, A5; float voltage = analogRead(A0) * (vref / 1024.0)
    cmdLine.serial().print(F("\r\n %A -- analogRead"));
#endif

#if HAS_SPI2_MAX541
    // TODO1: MAX541 max541(spi2_max541, spi2_max541_cs);
    cmdLine.serial().print(F("\r\n %D -- DAC output MAX541 (SPI2)"));
#endif

#if HAS_I2C // HAS_I2C
    // TODO: support I2C HAS_I2C // HAS_I2C
    // VERIFY: I2C utility commands HAS_I2C
    // VERIFY: report g_I2C_SCL_Hz = (F_CPU / ((TWBR * 2) + 16)) from last Wire_Sr.setClock(I2C_SCL_Hz);
    // %I... -- I2C diagnostics
    // %IP -- I2C probe
    // %IC scl=100khz ADDR=? -- I2C configure
    // %IW byte byte ... byte RD=? ADDR=0x -- write
    // %IR ADDR=? RD=? -- read
    // %I^ cmd=? -- i2c_smbus_read_word_data
    //g_I2C_SCL_Hz = (F_CPU / ((TWBR * 2) + 16));   // 'F_CPU' 'TWBR' not declared in this scope
    cmdLine.serial().print("\r\n %IC ADDR=0x%2.2x=(0x%2.2x>>1) SCL=%d=%1.3fkHz -- I2C config",
                            g_I2C_deviceAddress7, (g_I2C_deviceAddress7 << 1), g_I2C_SCL_Hz,
                            (g_I2C_SCL_Hz / 1000.));
    cmdLine.serial().print("\r\n %IW byte byte ... byte RD=? ADDR=0x%2.2x -- I2C write/read",
                            g_I2C_deviceAddress7);
    //
#if HAS_I2C
    // Menu ^ cmd=?) i2c_smbus_read_word_data
    cmdLine.serial().print(F("\r\n %I^ cmd=? -- i2c_smbus_read_word_data"));
    // test low-level I2C i2c_smbus_read_word_data
#endif // HAS_I2C
    //cmdLine.serial().print(F(" H) Hunt for attached I2C devices"));
    cmdLine.serial().print(F("\r\n %IP -- I2C Probe for attached devices"));
    // cmdLine.serial().print(F(" s) search i2c address"));
#endif // HAS_I2C

#if HAS_SPI // SUPPORT_SPI
    // TODO: support SPI HAS_SPI // SUPPORT_SPI
    // SPI test command  S (mosiData)+
    // %S... -- SPI diagnostics
    // %SC sclk=1Mhz -- SPI configure
    // %SW -- write (write and read)
    // %SR -- read (alias for %SW because SPI always write and read)
    // spi.format(8,0); // int bits_must_be_8, int mode=0_3 CPOL=0,CPHA=0 rising edge (initial default)
    // spi.format(8,1); // int bits_must_be_8, int mode=0_3 CPOL=0,CPHA=1 falling edge (initial default)
    // spi.format(8,2); // int bits_must_be_8, int mode=0_3 CPOL=1,CPHA=0 falling edge (initial default)
    // spi.format(8,3); // int bits_must_be_8, int mode=0_3 CPOL=1,CPHA=1 rising edge (initial default)
    // spi.frequency(1000000); // int SCLK_Hz=1000000 = 1MHz (initial default)
    // mode | POL PHA
    // -----+--------
    //   0  |  0   0
    //   1  |  0   1
    //   2  |  1   0
    //   3  |  1   1
    //cmdLine.serial().print(F(" S) SPI mosi,mosi,...mosi hex bytes SCLK=1000000 CPOL=0 CPHA=0"));
    // fixed: mbed-os-5.11: [Warning] format '%d' expects argument of type 'int', but argument 3 has type 'uint32_t {aka long unsigned int}' [-Wformat=]
    //cmdLine.serial().print("\r\n %SC SCLK=%ld=%1.3fMHz CPOL=%d CPHA=%d -- SPI config",
    //                        g_SPI_SCLK_Hz, (g_SPI_SCLK_Hz / 1000000.),
    //                        ((g_SPI_dataMode & SPI_MODE2) ? 1 : 0),
    //                        ((g_SPI_dataMode & SPI_MODE1) ? 1 : 0));
    cmdLine.serial().print(F("\r\n %SC SCLK="));
    // VERIFY: print SCLK=g_SPI_SCLK_Hz instead of "SCLK=1000000"
    cmdLine.serial().print(g_SPI_SCLK_Hz);
    cmdLine.serial().print(F("="));
    cmdLine.serial().print(g_SPI_SCLK_Hz / 1000000);
    cmdLine.serial().print(F("MHz"));
    cmdLine.serial().print(F(" CPOL="));
    // VERIFY: print CPOL=0 or 1 depending on g_SPI_dataMode & SPI_MODE2
    if (g_SPI_dataMode & SPI_MODE2) { Serial.print(1); } else {  cmdLine.serial().print(0); }
    cmdLine.serial().print(F(" CPHA="));
    // VERIFY: print CPHA=0 or 1 depending on g_SPI_dataMode & SPI_MODE1
    if (g_SPI_dataMode & SPI_MODE1) { Serial.print(1); } else {  cmdLine.serial().print(0); }
    cmdLine.serial().print(F(" -- SPI config"));
    cmdLine.serial().print(F("\r\n %SW mosi,mosi,...mosi -- SPI write hex bytes"));
    //cmdLine.serial().print(F("\r\n %SW mosi,mosi,...mosi -- SPI write hex bytes"));
    // VERIFY: parse new SPI settings parse_strCommandArgs() SCLK=1000000 CPOL=0 CPHA=0
#endif // SUPPORT_SPI
       //
       // Application-specific commands (help text) here
       //
#if APPLICATION_ArduinoPinsMonitor
# if APPLICATION_MAX5715 // main_menu_help
# elif APPLICATION_MAX11131 // main_menu_help
# elif APPLICATION_MAX5171 // main_menu_help
# elif APPLICATION_MAX11410 // main_menu_help
# elif APPLICATION_MAX12345 // main_menu_help
# else
    cmdLine.serial().print(F("\r\n A-Z,a-z,0-9 -- reserved for application use"));     // ArduinoPinsMonitor
# endif
#endif // APPLICATION_ArduinoPinsMonitor
       //
    extern bool MAX11131_menu_help(CmdLine & cmdLine); // defined in Test_Menu_MAX11131.cpp\n
    MAX11131_menu_help(cmdLine);
#if APPLICATION_MAX11410 // main_menu_help
    cmdLine.serial().print(F("\r\n ---xxx---"));
    // TODO1: MAX11410 main_menu_help
    cmdLine.serial().print(F("\r\n w reg=? data=? -- write register"));
    cmdLine.serial().print(F("\r\n r reg=? -- read register"));
    cmdLine.serial().print(F("\r\n TC -- thermocouple config"));
    cmdLine.serial().print(F("\r\n T -- RTD measurement"));
    cmdLine.serial().print(F("\r\n RC -- thermocouple config"));
    cmdLine.serial().print(F("\r\n R -- RTD measurement"));
    // Note: '~' is not recommended for menu commands, interferes with ssh
    cmdLine.serial().print(F("\r\n ---xxx---"));
#endif // APPLICATION_MAX11410
}


//--------------------------------------------------
//Optional Diagnostic function to print SPI transactions
void onSPIprint_handler(size_t byteCount, uint8_t mosiData[], uint8_t misoData[])
{
    cmdLine_serial.serial().print(F("\r\nSPI MOSI->"));
    for (uint8_t index = 0; index < byteCount; index++) {
        cmdLine_serial.serial().print(F(" 0x"));
        cmdLine_serial.serial().print(mosiData[index], HEX);
    }
    cmdLine_serial.serial().print(F("  MISO<-"));
    for (uint8_t index = 0; index < byteCount; index++) {
        cmdLine_serial.serial().print(F(" 0x"));
        cmdLine_serial.serial().print(misoData[index], HEX);
    }
    cmdLine_serial.serial().print(" ");
}

//--------------------------------------------------
// On End of Line, parse command buffer
void main_menu_onEOLcommandParser(CmdLine& cmdLine)
{
    switch (cmdLine[0])
    {
        case '?':
            main_menu_status(cmdLine);
            main_menu_help(cmdLine);
            // print command prompt
            //cmdLine.serial().print(F("\r\n>"));
            break;
        case '\r': case '\n':     // ignore blank line
        case '\0':     // ignore empty line
        case '#':     // ignore comment line
            // # -- lines beginning with # are comments
            main_menu_status(cmdLine);
            //~ main_menu_help(cmdLine);
            // print command prompt
            //cmdLine.serial().print(F("\r\n>"));
            break;
#if ECHO_EOF_ON_EOL
        case '\x04':     // Unicode (U+0004) EOT END OF TRANSMISSION = CTRL+D as EOF end of file
            cmdLine.serial().print(F("\x04"));     // immediately echo EOF for test scripting
            diagnostic_led_EOF();
            break;
        case '\x1a':     // Unicode (U+001A) SUB SUBSTITUTE = CTRL+Z as EOF end of file
            cmdLine.serial().print(F("\x1a"));     // immediately echo EOF for test scripting
            diagnostic_led_EOF();
            break;
#endif
#if 1 // APPLICATION_ArduinoPinsMonitor
        case '.':
        {
            // . -- SelfTest
            cmdLine.serial().print(F("SelfTest()"));
            SelfTest(cmdLine);
        }
        break;
#endif
#if 1 // APPLICATION_ArduinoPinsMonitor
        case '%':
        {
            pinsMonitor_submenu_onEOLcommandParser(cmdLine);
        }
        break;         // case '%'
#endif // APPLICATION_ArduinoPinsMonitor
       //
       // Application-specific commands here
       // alphanumeric command codes A-Z,a-z,0-9 reserved for application use
       //
#if APPLICATION_ArduinoPinsMonitor
#endif // APPLICATION_ArduinoPinsMonitor

        //
        // TODO1: add new commands here
        //
        default:
#if APPLICATION_MAX5715 // main_menu_onEOLcommandParser print command prompt
            extern bool MAX5715_menu_onEOLcommandParser(CmdLine & cmdLine); // defined in Test_Menu_MAX5715.cpp
            if (!MAX5715_menu_onEOLcommandParser(cmdLine))
#elif APPLICATION_MAX11131 // main_menu_onEOLcommandParser print command prompt
            extern bool MAX11131_menu_onEOLcommandParser(CmdLine & cmdLine); // defined in Test_Menu_MAX11131.cpp
            if (!MAX11131_menu_onEOLcommandParser(cmdLine))
#elif APPLICATION_MAX5171 // main_menu_onEOLcommandParser print command prompt
            extern bool MAX5171_menu_onEOLcommandParser(CmdLine & cmdLine); // defined in Test_Menu_MAX5171.cpp
            if (!MAX5171_menu_onEOLcommandParser(cmdLine))
#elif APPLICATION_MAX11410 // main_menu_onEOLcommandParser print command prompt
            extern bool MAX11410_menu_onEOLcommandParser(CmdLine & cmdLine); // defined in Test_Menu_MAX11410.cpp
            if (!MAX11410_menu_onEOLcommandParser(cmdLine))
#elif APPLICATION_MAX12345 // main_menu_onEOLcommandParser print command prompt
            extern bool MAX12345_menu_onEOLcommandParser(CmdLine & cmdLine); // defined in Test_Menu_MAX12345.cpp
            if (!MAX12345_menu_onEOLcommandParser(cmdLine))
#else
            if (0) // not_handled_by_device_submenu
#endif
            {
                cmdLine.serial().print(F("\r\n unknown command "));
                //~ cmdLine.serial().print("\r\n unknown command 0x%2.2x \"%s\"\r\n", cmdLine.str()[0], cmdLine.str());
# if HAS_DAPLINK_SERIAL
                cmdLine_DAPLINKserial.serial().print("\r\n unknown command 0x%2.2x \"%s\"\r\n",
                                                      cmdLine.str()[0], cmdLine.str());
# endif // HAS_DAPLINK_SERIAL
            }
    }     // switch (cmdLine[0])
//
// print command prompt
    print_command_prompt();
}


//--------------------------------------------------
// standard Arduino setup() function
//
void setup() {
  // put your setup code here, to run once:

    // example code: serial port banner message
    Serial.begin(9600); // serial baud rate
    Serial.print("MAX11131\r\n");


  cmdLine_serial.clear();
  //~ cmdLine_serial.serial().print("\r\n cmdLine_serial.serial().print test\r\n");
  cmdLine_serial.onEOLcommandParser = main_menu_onEOLcommandParser;
  //~ cmdLine_serial.diagnostic_led_EOF = diagnostic_led_EOF;
  //~ cmdLine_serial.on_immediate_0x21 = on_immediate_0x21;
  //~ cmdLine_serial.on_immediate_0x7b = on_immediate_0x7b;
  //~ cmdLine_serial.on_immediate_0x7d = on_immediate_0x7d;

  // Optional Diagnostic function to print SPI transactions
  g_MAX11131_device.onSPIprint = onSPIprint_handler;

  analogReference(DEFAULT); // Default: use supply voltage as analog reference
  //analogReference(INTERNAL); // Internal=1.1V; Arduino Pro Mini AREF has no external connection

  digitalWrite(SPI_CS_Pin, HIGH); // SPI CS inactive high
  pinMode (SPI_CS_Pin, OUTPUT); // ensure SPI CS is driven output

  digitalWrite(SPI_MOSI_Pin, LOW);
  pinMode (SPI_MOSI_Pin, OUTPUT);

  pinMode (SPI_MISO_Pin, INPUT);

  digitalWrite(SPI_SCLK_Pin, LOW);
  pinMode (SPI_SCLK_Pin, OUTPUT);

    //MAX11131 dac(MAX11131::MAX11131_IC);
    //dac.Init();

    g_MAX11131_device.Init();

        // Measure ADC channels in sequence from AIN0 to channelNumber_0_15.
        // @param[in] g_MAX11131_device.channelNumber_0_15: AIN Channel Number
        // @param[in] g_MAX11131_device.PowerManagement_0_2: 0=Normal, 1=AutoShutdown, 2=AutoStandby
        // @param[in] g_MAX11131_device.chan_id_0_1: ADC_MODE_CONTROL.CHAN_ID
        int channelId_0_15 = 15;
        g_MAX11131_device.channelNumber_0_15 = channelId_0_15;
        g_MAX11131_device.PowerManagement_0_2 = 0;
        g_MAX11131_device.chan_id_0_1 = 1;
        g_MAX11131_device.NumWords = g_MAX11131_device.ScanStandardExternalClock();

        // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
        // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
        g_MAX11131_device.ReadAINcode();
        // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
        // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs

        //wait(1.0);

  print_command_prompt();
}


//--------------------------------------------------
// standard Arduino loop() function
//
void loop() {
  // put your main code here, to run repeatedly:

  if (Serial.available())
  {
    int c = Serial.read(); // instead of getc() or fgetc()
    cmdLine_serial.append(c);
  } // if (Serial.available())

}
