﻿// /*******************************************************************************
// * Copyright (C) 2019 Maxim Integrated Products, Inc., All Rights Reserved.
// *
// * Permission is hereby granted, free of charge, to any person obtaining a
// * copy of this software and associated documentation files (the "Software"),
// * to deal in the Software without restriction, including without limitation
// * the rights to use, copy, modify, merge, publish, distribute, sublicense,
// * and/or sell copies of the Software, and to permit persons to whom the
// * Software is furnished to do so, subject to the following conditions:
// *
// * The above copyright notice and this permission notice shall be included
// * in all copies or substantial portions of the Software.
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
// * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// * OTHER DEALINGS IN THE SOFTWARE.
// *
// * Except as contained in this notice, the name of Maxim Integrated
// * Products, Inc. shall not be used except as stated in the Maxim Integrated
// * Products, Inc. Branding Policy.
// *
// * The mere transfer of this software does not imply any licenses
// * of trade secrets, proprietary technology, copyrights, patents,
// * trademarks, maskwork rights, or any other form of intellectual
// * property whatsoever. Maxim Integrated Products, Inc. retains all
// * ownership rights.
// *******************************************************************************
// */
// example code includes
// standard include for target platform -- Platform_Include_Boilerplate
#include "Arduino.h"
// SPI interface
#include "SPI.h"
// end Platform_Include_Boilerplate
#include "MAX11131.h"
#include "CmdLine.h"

#include "MAX11131.h"
extern MAX11131 g_MAX11131_device; // defined in main.cpp



// CODE GENERATOR: MAX11131 needs print_value(CmdLine& cmdLine, int16_t value_u12, int channelId)
//----------------------------------------
void print_value(CmdLine& cmdLine, int16_t value_u12, int channelId)
{
    int channelPairIndex = channelId / 2;
    // format: 1 0 0 0 1 UCH0/1 UCH2/3 UCH4/5 UCH6/7 UCH8/9 UCH10/11 UCH12/13 UCH14/15 PDIFF_COM x x
    // unused variable: int UCHn = (g_MAX11131_device.UNIPOLAR >> (10 - channelPairIndex)) & 0x01;
    int BCHn = (g_MAX11131_device.BIPOLAR >> (10 - channelPairIndex)) & 0x01;
    // unused variable: int RANGEn = (g_MAX11131_device.RANGE >> (10 - channelPairIndex)) & 0x01;
    //
    cmdLine.serial().print(" ch=");
    // TODO1: if CHANID=0 don't print ch=channelId
    if ((g_MAX11131_device.isExternalClock == 0) || (g_MAX11131_device.chan_id_0_1 == 1))
    {
        // Internal clock modes always use channel ID.
        // External clock modes use channel ID if ADC_MODE_CONTROL.CHAN_ID is 1.
        cmdLine.serial().print(channelId);
    } else {
        cmdLine.serial().print("?");
    }
    if (BCHn)
    {
        cmdLine.serial().print(F(" xb="));
        cmdLine.serial().print(g_MAX11131_device.TwosComplementValue(value_u12));
    }
    else
    {
        cmdLine.serial().print(F(" xu="));
        cmdLine.serial().print(value_u12);
    }
    cmdLine.serial().print(F(" = 0x"));
    cmdLine.serial().print((value_u12 & 0xFFFF), HEX);
    cmdLine.serial().print(F(" = "));
    // dtostrf width and precision: 2.5v / 4096 LSB = 0.0006103515625 volts per LSB
    // Arduino sprintf doesn't support %f format. Use char *dtostrf(double val, signed char width, unsigned char prec, char *s). see http://stackoverflow.com/a/27652012/2427089
    // dtostrf width and precision: 2.5v / 4096 LSB = 0.0006103515625 volts per LSB
    char strOutLineBuffer[16];
    dtostrf(g_MAX11131_device.VoltageOfCode(value_u12, channelId), 6, 4, strOutLineBuffer); // value, width, precision, char* buffer
    cmdLine.serial().print(strOutLineBuffer);
    cmdLine.serial().print("V");
}

// CODE GENERATOR: MAX11131 needs AINcode_print_value_chanID(CmdLine& cmdLine, int nWords)
//----------------------------------------
// read data words
// @pre RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
// @pre AINcode[NUM_CHANNELS] contains the latest readings in LSBs
// For internal clock modes, the data format always includes the channel address.
//     misoData16 = CH[3:0] DATA[11:0]
void AINcode_print_value_chanID(CmdLine& cmdLine, int nWords)
{
    cmdLine.serial().print(F("\r\nScanRead_nWords_chanID nWords="));
    cmdLine.serial().println(nWords);
    for (int index = 0; index < nWords; index++) {
        //~ int16_t misoData16 = MAX11131_ScanRead();
        // For internal clock modes, the data format always includes the channel address.
        //     misoData16 = CH[3:0] DATA[11:0]
        int16_t value_u12 = (g_MAX11131_device.RAW_misoData16[index] & 0x0FFF);
        int channelId = ((g_MAX11131_device.RAW_misoData16[index] >> 12) & 0x000F);
        // diagnostic: print raw MISO data
        cmdLine.serial().print("      MAX11131.MISO[");
        cmdLine.serial().print(index);
        cmdLine.serial().print("]=0x");
        cmdLine.serial().print((g_MAX11131_device.RAW_misoData16[index] & 0xFFFF), HEX);
        cmdLine.serial().print(":");
        print_value(cmdLine, value_u12, channelId);
        cmdLine.serial().println();
    }
}

// CODE GENERATOR: MAX11131 needs AINcode_print_value_externalClock(CmdLine& cmdLine, int nWords)
//----------------------------------------
// read data words
// @pre RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
// @pre AINcode[NUM_CHANNELS] contains the latest readings in LSBs
// For external clock modes, the data format returned depends on the CHAN_ID bit.
//     when CHAN_ID = 0: misoData16 = 0 DATA[11:0] x x x
//     when CHAN_ID = 1: misoData16 = CH[3:0] DATA[11:0]
void AINcode_print_value_externalClock(CmdLine& cmdLine, int nWords)
{
    // For external clock modes, the data format returned depends on the CHAN_ID bit.
    //     when CHAN_ID = 0: misoData16 = 0 DATA[11:0] x x x
    //     when CHAN_ID = 1: misoData16 = CH[3:0] DATA[11:0]
    // For internal clock modes, the data format always includes the channel address.
    //     misoData16 = CH[3:0] DATA[11:0]
    if (g_MAX11131_device.chan_id_0_1 != 0) {
        AINcode_print_value_chanID(cmdLine, nWords);
        return;
    }
    cmdLine.serial().print(F("\r\nScanRead_nWords_externalClock nWords="));
    cmdLine.serial().println(nWords);
    for (int index = 0; index < nWords; index++) {
        // int16_t misoData16 = MAX11131_ScanRead();
        int16_t value_u12 = ((g_MAX11131_device.RAW_misoData16[index] >> 3) & 0x0FFF);
        int channelId = g_MAX11131_device.channelNumber_0_15;
        // diagnostic: print raw MISO data
        cmdLine.serial().print("      MAX11131.MISO[");
        cmdLine.serial().print(index);
        cmdLine.serial().print("]=0x");
        cmdLine.serial().print((g_MAX11131_device.RAW_misoData16[index] & 0xFFFF), HEX);
        cmdLine.serial().print(":");
        print_value(cmdLine, value_u12, channelId);
        cmdLine.serial().println();
    }
}

// CODE GENERATOR: MAX11131 needs AINcode_print_value_chanID_mean(CmdLine& cmdLine, int nWords)
//----------------------------------------
// read data words and calculate mean, stddev
// @pre RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
// @pre AINcode[NUM_CHANNELS] contains the latest readings in LSBs
void AINcode_print_value_chanID_mean(CmdLine& cmdLine, int nWords)
{
  cmdLine.serial().print(F("\r\nScanRead_nWords_chanID_mean nWords="));
  cmdLine.serial().println(nWords);
  double Sx = 0;
  double Sxx = 0;
  for (int index = 0; index < nWords; index++) {
    //~ int16_t misoData16 = MAX11131_ScanRead();
    // For internal clock modes, the data format always includes the channel address.
    //     misoData16 = CH[3:0] DATA[11:0]
    int16_t value_u12 = (g_MAX11131_device.RAW_misoData16[index] & 0x0FFF);
    int channelId = ((g_MAX11131_device.RAW_misoData16[index] >> 12) & 0x000F);
    // TODO: sign-extend value_s12 from value_u12
    //
    cmdLine.serial().print(F("n="));
    cmdLine.serial().print(index);
    print_value(cmdLine, value_u12, channelId);
    //
    Sx = Sx + value_u12;
    Sxx = Sxx + ((double)value_u12 * value_u12);
    cmdLine.serial().print(F(" Sx="));
    cmdLine.serial().print(Sx);
    cmdLine.serial().print(F(" Sxx="));
    cmdLine.serial().print(Sxx);
    cmdLine.serial().println();
  }
  double mean = Sx / nWords;
  cmdLine.serial().print(F("  mean="));
  cmdLine.serial().print(mean);
  cmdLine.serial().print(F("=0x"));
  cmdLine.serial().print( (int)mean, HEX );
  // calculate standard deviation from N, Sx, Sxx
  if (nWords >= 2)
  {
    double variance = (Sxx - ( Sx * Sx / nWords) ) / (nWords - 1);
    cmdLine.serial().print(F("  variance="));
    cmdLine.serial().print(variance);
    // stddev = square root of variance
    double stddev = sqrt(variance);
    cmdLine.serial().print(F("  stddev="));
    cmdLine.serial().print(stddev);
  }
  cmdLine.serial().println();
}

bool MAX11131_menu_help(CmdLine & cmdLine)
{
    cmdLine.serial().print(F("\r\n ! -- Init"));
    cmdLine.serial().print(F("\r\n 0 NumWords=? -- ReadAINcode"));
    cmdLine.serial().print(F("\r\n 1 ch=? pm=? id=? -- ScanManual"));
    cmdLine.serial().print(F("\r\n 2 ch=? av=? n=? swcnv=? pm=? -- ScanRepeat"));
    cmdLine.serial().print(F("\r\n 3 ch=? av=? pm=? swcnv=? -- ScanStandardInternalClock"));
    cmdLine.serial().print(F("\r\n 4 ch=? pm=? id=? -- ScanStandardExternalClock"));
    cmdLine.serial().print(F("\r\n 5 ch=? av=? pm=? swcnv=? -- ScanUpperInternalClock"));
    cmdLine.serial().print(F("\r\n 6 ch=? pm=? id=? -- ScanUpperExternalClock"));
    cmdLine.serial().print(F("\r\n 7 enableMask=? av=? pm=? swcnv=? -- ScanCustomInternalClock"));
    cmdLine.serial().print(F("\r\n 8 enableMask=? pm=? id=? -- ScanCustomExternalClock"));
    cmdLine.serial().print(F("\r\n 9 channelsPattern...=? pm=? id=? -- ScanSampleSetExternalClock"));
    cmdLine.serial().print(F("\r\n IB ch=? -- Reconfigure_DifferentialBipolarFSVref"));
    cmdLine.serial().print(F("\r\n IR ch=? -- Reconfigure_DifferentialBipolarFS2Vref"));
    cmdLine.serial().print(F("\r\n IS ch=? -- Reconfigure_SingleEnded"));
    cmdLine.serial().print(F("\r\n IU ch=? -- Reconfigure_DifferentialUnipolar"));
    //
    cmdLine.serial().print(F("\r\n @ -- print MAX11131 configuration"));
    //
        // case 'G'..'Z','g'..'z' are reserved for GPIO commands
        // case 'A'..'F','a'..'f' may be available if not claimed by bitstream commands
    cmdLine.serial().print(F("\r\n C -- CNVST output PulseLow")); // TODO: ExternFunctionGPIOPinCommand testMenuGPIOItemsDict
    cmdLine.serial().print(F("\r\n E -- EOC input value")); // TODO: ExternFunctionGPIOPinCommand testMenuGPIOItemsDict

}

bool MAX11131_menu_onEOLcommandParser(CmdLine & cmdLine)
{


                    // parse argument int16_t ADC_CONFIGURATION
        int16_t ADC_CONFIGURATION = g_MAX11131_device.ADC_CONFIGURATION; // default to global property value
        if (cmdLine.parse_int16_dec("ADC_CONFIGURATION", ADC_CONFIGURATION))
        {
            g_MAX11131_device.ADC_CONFIGURATION = ADC_CONFIGURATION; // update global property value
        }

                    // parse argument int16_t ADC_MODE_CONTROL
        int16_t ADC_MODE_CONTROL = g_MAX11131_device.ADC_MODE_CONTROL; // default to global property value
        if (cmdLine.parse_int16_dec("ADC_MODE_CONTROL", ADC_MODE_CONTROL))
        {
            g_MAX11131_device.ADC_MODE_CONTROL = ADC_MODE_CONTROL; // update global property value
        }

                    // parse argument int16_t BIPOLAR
        int16_t BIPOLAR = g_MAX11131_device.BIPOLAR; // default to global property value
        if (cmdLine.parse_int16_dec("BIPOLAR", BIPOLAR))
        {
            g_MAX11131_device.BIPOLAR = BIPOLAR; // update global property value
        }

                    // parse argument int16_t CSCAN0
        int16_t CSCAN0 = g_MAX11131_device.CSCAN0; // default to global property value
        if (cmdLine.parse_int16_dec("CSCAN0", CSCAN0))
        {
            g_MAX11131_device.CSCAN0 = CSCAN0; // update global property value
        }

                    // parse argument int16_t CSCAN1
        int16_t CSCAN1 = g_MAX11131_device.CSCAN1; // default to global property value
        if (cmdLine.parse_int16_dec("CSCAN1", CSCAN1))
        {
            g_MAX11131_device.CSCAN1 = CSCAN1; // update global property value
        }

                    // parse argument uint16_t NumWords
        uint16_t NumWords = g_MAX11131_device.NumWords; // default to global property value
        if (cmdLine.parse_uint16_dec("NumWords", NumWords))
        {
            g_MAX11131_device.NumWords = NumWords; // update global property value
        }

                    // parse argument uint8_t PowerManagement_0_2
        uint8_t PowerManagement_0_2 = g_MAX11131_device.PowerManagement_0_2; // default to global property value
        if (cmdLine.parse_uint8_dec("PowerManagement_0_2", PowerManagement_0_2))
        {
            g_MAX11131_device.PowerManagement_0_2 = PowerManagement_0_2; // update global property value
        }
                    // "pm" is an alias for argument "PowerManagement_0_2"
        if (cmdLine.parse_uint8_dec("pm", PowerManagement_0_2))
        {
            g_MAX11131_device.PowerManagement_0_2 = PowerManagement_0_2; // update global property value
        }

                    // parse argument int16_t RANGE
        int16_t RANGE = g_MAX11131_device.RANGE; // default to global property value
        if (cmdLine.parse_int16_dec("RANGE", RANGE))
        {
            g_MAX11131_device.RANGE = RANGE; // update global property value
        }

                    // parse argument int16_t SAMPLESET
        int16_t SAMPLESET = g_MAX11131_device.SAMPLESET; // default to global property value
        if (cmdLine.parse_int16_dec("SAMPLESET", SAMPLESET))
        {
            g_MAX11131_device.SAMPLESET = SAMPLESET; // update global property value
        }

                    // parse argument uint8_t SPI_MOSI_Semantic
        uint8_t SPI_MOSI_Semantic = g_MAX11131_device.SPI_MOSI_Semantic; // default to global property value
        if (cmdLine.parse_uint8_dec("SPI_MOSI_Semantic", SPI_MOSI_Semantic))
        {
            g_MAX11131_device.SPI_MOSI_Semantic = SPI_MOSI_Semantic; // update global property value
        }

                    // parse argument uint8_t ScanMode
        uint8_t ScanMode = g_MAX11131_device.ScanMode; // default to global property value
        if (cmdLine.parse_uint8_dec("ScanMode", ScanMode))
        {
            g_MAX11131_device.ScanMode = ScanMode; // update global property value
        }

                    // parse argument int16_t UNIPOLAR
        int16_t UNIPOLAR = g_MAX11131_device.UNIPOLAR; // default to global property value
        if (cmdLine.parse_int16_dec("UNIPOLAR", UNIPOLAR))
        {
            g_MAX11131_device.UNIPOLAR = UNIPOLAR; // update global property value
        }

                    // parse argument double VRef
        double VRef = g_MAX11131_device.VRef; // default to global property value
        if (cmdLine.parse_double("VRef", VRef))
        {
            g_MAX11131_device.VRef = VRef; // update global property value
        }

                    // parse argument uint8_t average_0_4_8_16_32
        uint8_t average_0_4_8_16_32 = g_MAX11131_device.average_0_4_8_16_32; // default to global property value
        if (cmdLine.parse_uint8_dec("average_0_4_8_16_32", average_0_4_8_16_32))
        {
            g_MAX11131_device.average_0_4_8_16_32 = average_0_4_8_16_32; // update global property value
        }
                    // "av" is an alias for argument "average_0_4_8_16_32"
        if (cmdLine.parse_uint8_dec("av", average_0_4_8_16_32))
        {
            g_MAX11131_device.average_0_4_8_16_32 = average_0_4_8_16_32; // update global property value
        }

                    // parse argument uint8_t chan_id_0_1
        uint8_t chan_id_0_1 = g_MAX11131_device.chan_id_0_1; // default to global property value
        if (cmdLine.parse_uint8_dec("chan_id_0_1", chan_id_0_1))
        {
            g_MAX11131_device.chan_id_0_1 = chan_id_0_1; // update global property value
        }
                    // "id" is an alias for argument "chan_id_0_1"
        if (cmdLine.parse_uint8_dec("id", chan_id_0_1))
        {
            g_MAX11131_device.chan_id_0_1 = chan_id_0_1; // update global property value
        }

                    // parse argument uint8_t channelNumber_0_15
        uint8_t channelNumber_0_15 = g_MAX11131_device.channelNumber_0_15; // default to global property value
        if (cmdLine.parse_uint8_dec("channelNumber_0_15", channelNumber_0_15))
        {
            g_MAX11131_device.channelNumber_0_15 = channelNumber_0_15; // update global property value
        }
                    // "ch" is an alias for argument "channelNumber_0_15"
        if (cmdLine.parse_uint8_dec("ch", channelNumber_0_15))
        {
            g_MAX11131_device.channelNumber_0_15 = channelNumber_0_15; // update global property value
        }

                    // parse argument int16_t enabledChannelsMask
        int16_t enabledChannelsMask = g_MAX11131_device.enabledChannelsMask; // default to global property value
        if (cmdLine.parse_int16_dec("enabledChannelsMask", enabledChannelsMask))
        {
            g_MAX11131_device.enabledChannelsMask = enabledChannelsMask; // update global property value
        }
                    // "enableMask" is an alias for argument "enabledChannelsMask"
        if (cmdLine.parse_int16_dec("enableMask", enabledChannelsMask))
        {
            g_MAX11131_device.enabledChannelsMask = enabledChannelsMask; // update global property value
        }

                    // parse argument uint8_t enabledChannelsPatternLength_1_256
        uint8_t enabledChannelsPatternLength_1_256 = g_MAX11131_device.enabledChannelsPatternLength_1_256; // default to global property value
        if (cmdLine.parse_uint8_dec("enabledChannelsPatternLength_1_256", enabledChannelsPatternLength_1_256))
        {
            g_MAX11131_device.enabledChannelsPatternLength_1_256 = enabledChannelsPatternLength_1_256; // update global property value
        }

                    // parse argument uint8_t isExternalClock
        uint8_t isExternalClock = g_MAX11131_device.isExternalClock; // default to global property value
        if (cmdLine.parse_uint8_dec("isExternalClock", isExternalClock))
        {
            g_MAX11131_device.isExternalClock = isExternalClock; // update global property value
        }

                    // parse argument uint8_t nscan_4_8_12_16
        uint8_t nscan_4_8_12_16 = g_MAX11131_device.nscan_4_8_12_16; // default to global property value
        if (cmdLine.parse_uint8_dec("nscan_4_8_12_16", nscan_4_8_12_16))
        {
            g_MAX11131_device.nscan_4_8_12_16 = nscan_4_8_12_16; // update global property value
        }
                    // "n" is an alias for argument "nscan_4_8_12_16"
        if (cmdLine.parse_uint8_dec("n", nscan_4_8_12_16))
        {
            g_MAX11131_device.nscan_4_8_12_16 = nscan_4_8_12_16; // update global property value
        }

                    // parse argument uint8_t swcnv_0_1
        uint8_t swcnv_0_1 = g_MAX11131_device.swcnv_0_1; // default to global property value
        if (cmdLine.parse_uint8_dec("swcnv_0_1", swcnv_0_1))
        {
            g_MAX11131_device.swcnv_0_1 = swcnv_0_1; // update global property value
        }
                    // "swcnv" is an alias for argument "swcnv_0_1"
        if (cmdLine.parse_uint8_dec("swcnv", swcnv_0_1))
        {
            g_MAX11131_device.swcnv_0_1 = swcnv_0_1; // update global property value
        }

    switch (cmdLine[0])
    {
        case '@':
        {
                    cmdLine.serial().print(F("ADC_MODE_CONTROL = "));
                    cmdLine.serial().print(g_MAX11131_device.ADC_MODE_CONTROL);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.ADC_MODE_CONTROL, HEX);
                    cmdLine.serial().print(F("ADC_CONFIGURATION = "));
                    cmdLine.serial().print(g_MAX11131_device.ADC_CONFIGURATION);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.ADC_CONFIGURATION, HEX);
                    cmdLine.serial().print(F("UNIPOLAR = "));
                    cmdLine.serial().print(g_MAX11131_device.UNIPOLAR);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.UNIPOLAR, HEX);
                    cmdLine.serial().print(F("BIPOLAR = "));
                    cmdLine.serial().print(g_MAX11131_device.BIPOLAR);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.BIPOLAR, HEX);
                    cmdLine.serial().print(F("RANGE = "));
                    cmdLine.serial().print(g_MAX11131_device.RANGE);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.RANGE, HEX);
                    cmdLine.serial().print(F("CSCAN0 = "));
                    cmdLine.serial().print(g_MAX11131_device.CSCAN0);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.CSCAN0, HEX);
                    cmdLine.serial().print(F("CSCAN1 = "));
                    cmdLine.serial().print(g_MAX11131_device.CSCAN1);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.CSCAN1, HEX);
                    cmdLine.serial().print(F("SAMPLESET = "));
                    cmdLine.serial().print(g_MAX11131_device.SAMPLESET);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.SAMPLESET, HEX);
                    cmdLine.serial().print(F("enabledChannelsPatternLength_1_256 = "));
                    cmdLine.serial().print(g_MAX11131_device.enabledChannelsPatternLength_1_256);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.enabledChannelsPatternLength_1_256, HEX);
                for(int index = 0; (index < g_MAX11131_device.enabledChannelsPatternLength_1_256) && (index < 16); index++) {
                    cmdLine.serial().print(F("enabledChannelsPattern[")); cmdLine.serial().print(index); cmdLine.serial().print(F("] = "));
                    cmdLine.serial().print(g_MAX11131_device.enabledChannelsPattern[index]);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.enabledChannelsPattern[index], HEX);
                }
                    cmdLine.serial().print(F("SPI_MOSI_Semantic = "));
                    cmdLine.serial().print(g_MAX11131_device.SPI_MOSI_Semantic);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.SPI_MOSI_Semantic, HEX);
                    cmdLine.serial().print(F("NumWords = "));
                    cmdLine.serial().print(g_MAX11131_device.NumWords);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.NumWords, HEX);
                    cmdLine.serial().print(F("isExternalClock = "));
                    cmdLine.serial().print(g_MAX11131_device.isExternalClock);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.isExternalClock, HEX);
                    cmdLine.serial().print(F("ScanMode = "));
                    cmdLine.serial().print(g_MAX11131_device.ScanMode);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.ScanMode, HEX);
                    cmdLine.serial().print(F("channelNumber_0_15 = "));
                    cmdLine.serial().print(g_MAX11131_device.channelNumber_0_15);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.channelNumber_0_15, HEX);
                    cmdLine.serial().print(F("PowerManagement_0_2 = "));
                    cmdLine.serial().print(g_MAX11131_device.PowerManagement_0_2);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.PowerManagement_0_2, HEX);
                    cmdLine.serial().print(F("chan_id_0_1 = "));
                    cmdLine.serial().print(g_MAX11131_device.chan_id_0_1);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.chan_id_0_1, HEX);
                    cmdLine.serial().print(F("average_0_4_8_16_32 = "));
                    cmdLine.serial().print(g_MAX11131_device.average_0_4_8_16_32);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.average_0_4_8_16_32, HEX);
                    cmdLine.serial().print(F("nscan_4_8_12_16 = "));
                    cmdLine.serial().print(g_MAX11131_device.nscan_4_8_12_16);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.nscan_4_8_12_16, HEX);
                    cmdLine.serial().print(F("swcnv_0_1 = "));
                    cmdLine.serial().print(g_MAX11131_device.swcnv_0_1);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.swcnv_0_1, HEX);
                    cmdLine.serial().print(F("enabledChannelsMask = "));
                    cmdLine.serial().print(g_MAX11131_device.enabledChannelsMask);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.enabledChannelsMask, HEX);
                for(int index = 0; (index < 16) && (index < 16); index++) {
                    cmdLine.serial().print(F("AINcode[")); cmdLine.serial().print(index); cmdLine.serial().print(F("] = "));
                    cmdLine.serial().print(g_MAX11131_device.AINcode[index]);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.AINcode[index], HEX);
                }
                for(int index = 0; (index < 256) && (index < 16); index++) {
                    cmdLine.serial().print(F("RAW_misoData16[")); cmdLine.serial().print(index); cmdLine.serial().print(F("] = "));
                    cmdLine.serial().print(g_MAX11131_device.RAW_misoData16[index]);
                    cmdLine.serial().print(F(" = 0x"));
                    cmdLine.serial().println(g_MAX11131_device.RAW_misoData16[index], HEX);
                }
                    cmdLine.serial().print(F("VRef = "));
                    cmdLine.serial().println(g_MAX11131_device.VRef); // TODO ARDUINO PRINT FLOAT NUMBER
                    return true; // command handled by MAX11131
            break;
        }
        case 'C':
        {
                // TODO output PulseLow
                g_MAX11131_device.CNVSToutputPulseLow();
                    return true; // command handled by MAX11131
            break;
        }
        case 'E':
        {
                // TODO capture and print input Value
                cmdLine.serial().print(g_MAX11131_device.EOCinputValue());
                    return true; // command handled by MAX11131
            break;
        }
        // case '0'..'9','A'..'F','a'..'f' letters are reserved for bitstream commands
        case '!':
        {
                    // test menu command '!' handler:
                    // helpString='! -- Init'
                    // CMD_='None'
                    // CommandName='Init'
                    // CommandParamIn='void'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    cmdLine.serial().print(F("Init"));
                    // call function Init
                    g_MAX11131_device.Init();
                    return true; // command handled by MAX11131
        } // end case '!'
        break;
        case '0':
        {
                    // test menu command '0' handler:
                    // helpString='0 NumWords=? -- ReadAINcode'
                    // CMD_='SCAN_0000_NOP'
                    // CommandName='ReadAINcode'
                    // CommandParamIn='void'
                    // CommandReturnType='void'
                    // @Pre='@pre one of the Scan functions was called, setting g_MAX11131_device.NumWords'
                    // @Post='@post g_MAX11131_device.RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data,@post g_MAX11131_device.AINcode[NUM_CHANNELS] contains the latest readings in LSBs'
                    // @Return=''
                    // exception MAX11131 Menu item '0' ReadAINcode logic flow -- omit ReadAINcode call here, will be handled in postprocessing
                    cmdLine.serial().print(F("ReadAINcode"));
                    //
                    // CODE GENERATOR: MAX11131 ReadAINCode and print data
                    if (g_MAX11131_device.isExternalClock)
                    {
                        cmdLine.serial().print(F(" External Clock"));
                        //
                        // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                        // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                        g_MAX11131_device.ReadAINcode();
                        // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                        // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                        //
                        AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    }
                    else
                    {
                        cmdLine.serial().print(F(" Internal Clock"));
                        //
                        // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                        // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                        g_MAX11131_device.ReadAINcode();
                        // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                        // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                        //
                        AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    }
                    return true; // command handled by MAX11131
        } // end case '0'
        break;
        case '1':
        {
                    // test menu command '1' handler:
                    // helpString='1 ch=? pm=? id=? -- ScanManual'
                    // CMD_='SCAN_0001_Manual'
                    // CommandName='ScanManual'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanManual"));
                    // call function ScanManual
                    int result = g_MAX11131_device.ScanManual();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanManual ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '1'
        break;
        case '2':
        {
                    // test menu command '2' handler:
                    // helpString='2 ch=? av=? n=? swcnv=? pm=? -- ScanRepeat'
                    // CMD_='SCAN_0010_Repeat'
                    // CommandName='ScanRepeat'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanRepeat"));
                    // call function ScanRepeat
                    int result = g_MAX11131_device.ScanRepeat();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanRepeat ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID_mean(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '2'
        break;
        case '3':
        {
                    // test menu command '3' handler:
                    // helpString='3 ch=? av=? pm=? swcnv=? -- ScanStandardInternalClock'
                    // CMD_='SCAN_0011_StandardInternalClock'
                    // CommandName='ScanStandardInternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanStandardInternalClock"));
                    // call function ScanStandardInternalClock
                    int result = g_MAX11131_device.ScanStandardInternalClock();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanStandardInternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '3'
        break;
        case '4':
        {
                    // test menu command '4' handler:
                    // helpString='4 ch=? pm=? id=? -- ScanStandardExternalClock'
                    // CMD_='SCAN_0100_StandardExternalClock'
                    // CommandName='ScanStandardExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanStandardExternalClock"));
                    // call function ScanStandardExternalClock
                    int result = g_MAX11131_device.ScanStandardExternalClock();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanStandardExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '4'
        break;
        case '5':
        {
                    // test menu command '5' handler:
                    // helpString='5 ch=? av=? pm=? swcnv=? -- ScanUpperInternalClock'
                    // CMD_='SCAN_0101_UpperInternalClock'
                    // CommandName='ScanUpperInternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanUpperInternalClock"));
                    // call function ScanUpperInternalClock
                    int result = g_MAX11131_device.ScanUpperInternalClock();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanUpperInternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '5'
        break;
        case '6':
        {
                    // test menu command '6' handler:
                    // helpString='6 ch=? pm=? id=? -- ScanUpperExternalClock'
                    // CMD_='SCAN_0110_UpperExternalClock'
                    // CommandName='ScanUpperExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanUpperExternalClock"));
                    // call function ScanUpperExternalClock
                    int result = g_MAX11131_device.ScanUpperExternalClock();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanUpperExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '6'
        break;
        case '7':
        {
                    // test menu command '7' handler:
                    // helpString='7 enableMask=? av=? pm=? swcnv=? -- ScanCustomInternalClock'
                    // CMD_='SCAN_0111_CustomInternalClock'
                    // CommandName='ScanCustomInternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanCustomInternalClock"));
                    // call function ScanCustomInternalClock
                    int result = g_MAX11131_device.ScanCustomInternalClock();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanCustomInternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '7'
        break;
        case '8':
        {
                    // test menu command '8' handler:
                    // helpString='8 enableMask=? pm=? id=? -- ScanCustomExternalClock'
                    // CMD_='SCAN_1000_CustomExternalClock'
                    // CommandName='ScanCustomExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().print(F("ScanCustomExternalClock"));
                    // call function ScanCustomExternalClock
                    int result = g_MAX11131_device.ScanCustomExternalClock();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanCustomExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '8'
        break;
        case '9':
        {
                    // test menu command '9' handler:
                    // helpString='9 channelsPattern...=? pm=? id=? -- ScanSampleSetExternalClock'
                    // CMD_='SCAN_1001_SampleSetExternalClock'
                    // CommandName='ScanSampleSetExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre='@pre g_MAX11131_device.enabledChannelsPatternLength_1_256: number of channel selections,@pre g_MAX11131_device.enabledChannelsPattern: array containing channel selection pattern'
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    // exception MAX11131 Menu item '9' ScanSampleSetExternalClock
                    // parse channelsPattern using parse_byteCount_byteList_dec(size_t& byteCount, char *mosiDataBuf, size_t mosiDataBufSize)
                    size_t byteCount = g_MAX11131_device.enabledChannelsPatternLength_1_256;
                    char *mosiDataBuf = (char *)g_MAX11131_device.enabledChannelsPattern; // cast from uint8_t*
                    size_t mosiDataBufSize = sizeof(g_MAX11131_device.enabledChannelsPattern);
                    cmdLine.parse_byteCount_byteList_dec(byteCount, mosiDataBuf, mosiDataBufSize);
                    g_MAX11131_device.enabledChannelsPatternLength_1_256 = byteCount;
                    cmdLine.serial().print(F("ScanSampleSetExternalClock"));
                    // call function ScanSampleSetExternalClock
                    int result = g_MAX11131_device.ScanSampleSetExternalClock();
                    cmdLine.serial().print(F(" ="));
                    cmdLine.serial().println(result, DEC);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanSampleSetExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '9'
        break;
        case 'I':
        {
            switch (cmdLine[1])
            {
                case 'B':
                {
                    // test menu command 'IB' handler:
                    // helpString='IB ch=? -- Reconfigure_DifferentialBipolarFSVref'
                    // CMD_='None'
                    // CommandName='Reconfigure_DifferentialBipolarFSVref'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().print(F("Reconfigure_DifferentialBipolarFSVref"));
                    cmdLine.serial().print(F(" channel_0_15="));
                    cmdLine.serial().print(channel_0_15);
                    cmdLine.serial().println();
                    // call function Reconfigure_DifferentialBipolarFSVref(channel_0_15)
                    g_MAX11131_device.Reconfigure_DifferentialBipolarFSVref(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IB'
                break;
                case 'R':
                {
                    // test menu command 'IR' handler:
                    // helpString='IR ch=? -- Reconfigure_DifferentialBipolarFS2Vref'
                    // CMD_='None'
                    // CommandName='Reconfigure_DifferentialBipolarFS2Vref'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().print(F("Reconfigure_DifferentialBipolarFS2Vref"));
                    cmdLine.serial().print(F(" channel_0_15="));
                    cmdLine.serial().print(channel_0_15);
                    cmdLine.serial().println();
                    // call function Reconfigure_DifferentialBipolarFS2Vref(channel_0_15)
                    g_MAX11131_device.Reconfigure_DifferentialBipolarFS2Vref(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IR'
                break;
                case 'S':
                {
                    // test menu command 'IS' handler:
                    // helpString='IS ch=? -- Reconfigure_SingleEnded'
                    // CMD_='None'
                    // CommandName='Reconfigure_SingleEnded'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().print(F("Reconfigure_SingleEnded"));
                    cmdLine.serial().print(F(" channel_0_15="));
                    cmdLine.serial().print(channel_0_15);
                    cmdLine.serial().println();
                    // call function Reconfigure_SingleEnded(channel_0_15)
                    g_MAX11131_device.Reconfigure_SingleEnded(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IS'
                break;
                case 'U':
                {
                    // test menu command 'IU' handler:
                    // helpString='IU ch=? -- Reconfigure_DifferentialUnipolar'
                    // CMD_='None'
                    // CommandName='Reconfigure_DifferentialUnipolar'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().print(F("Reconfigure_DifferentialUnipolar"));
                    cmdLine.serial().print(F(" channel_0_15="));
                    cmdLine.serial().print(channel_0_15);
                    cmdLine.serial().println();
                    // call function Reconfigure_DifferentialUnipolar(channel_0_15)
                    g_MAX11131_device.Reconfigure_DifferentialUnipolar(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IU'
                break;
            } // end nested switch (cmdLine[1])
            break;
        } // end case 'I'
    } // end switch (cmdLine[0])
    return false; // command not handled by MAX11131
} // end bool MAX11131_menu_onEOLcommandParser(CmdLine & cmdLine)

