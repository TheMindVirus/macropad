﻿// /*******************************************************************************
// * Copyright (C) 2019 Maxim Integrated Products, Inc., All Rights Reserved.
// *
// * Permission is hereby granted, free of charge, to any person obtaining a
// * copy of this software and associated documentation files (the "Software"),
// * to deal in the Software without restriction, including without limitation
// * the rights to use, copy, modify, merge, publish, distribute, sublicense,
// * and/or sell copies of the Software, and to permit persons to whom the
// * Software is furnished to do so, subject to the following conditions:
// *
// * The above copyright notice and this permission notice shall be included
// * in all copies or substantial portions of the Software.
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
// * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
// * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// * OTHER DEALINGS IN THE SOFTWARE.
// *
// * Except as contained in this notice, the name of Maxim Integrated
// * Products, Inc. shall not be used except as stated in the Maxim Integrated
// * Products, Inc. Branding Policy.
// *
// * The mere transfer of this software does not imply any licenses
// * of trade secrets, proprietary technology, copyrights, patents,
// * trademarks, maskwork rights, or any other form of intellectual
// * property whatsoever. Maxim Integrated Products, Inc. retains all
// * ownership rights.
// *******************************************************************************
// */
// example code includes
// standard include for target platform -- Platform_Include_Boilerplate
#include "mbed.h"
// Platforms:
//   - MAX32625MBED
//      - supports mbed-os-5.11, requires USBDevice library
//      - add https://developer.mbed.org/teams/MaximIntegrated/code/USBDevice/
//      - remove max32630fthr library (if present)
//      - remove MAX32620FTHR library (if present)
//   - MAX32600MBED
//      - remove max32630fthr library (if present)
//      - remove MAX32620FTHR library (if present)
//      - Windows 10 note:  Don't connect HDK until you are ready to load new firmware into the board.
//   - NUCLEO_F446RE
//      - remove USBDevice library
//      - remove max32630fthr library (if present)
//      - remove MAX32620FTHR library (if present)
//   - NUCLEO_F401RE
//      - remove USBDevice library
//      - remove max32630fthr library (if present)
//      - remove MAX32620FTHR library (if present)
//   - MAX32630FTHR
//      - #include "max32630fthr.h"
//      - add http://os.mbed.org/teams/MaximIntegrated/code/max32630fthr/
//      - remove MAX32620FTHR library (if present)
//   - MAX32620FTHR
//      - #include "MAX32620FTHR.h"
//      - remove max32630fthr library (if present)
//      - add https://os.mbed.com/teams/MaximIntegrated/code/MAX32620FTHR/
//      - not tested yet
//   - MAX32625PICO
//      - remove max32630fthr library (if present)
//      - remove MAX32620FTHR library (if present)
//      - not tested yet
//
// end Platform_Include_Boilerplate
#include "MAX11131.h"
#include "CmdLine.h"

#include "MAX11131.h"
extern MAX11131 g_MAX11131_device; // defined in main.cpp



bool MAX11131_menu_help(CmdLine & cmdLine)
{
    cmdLine.serial().printf("\r\n ! -- Init");
    cmdLine.serial().printf("\r\n 0 NumWords=? -- ReadAINcode");
    cmdLine.serial().printf("\r\n 1 ch=? pm=? id=? -- ScanManual");
    cmdLine.serial().printf("\r\n 2 ch=? av=? n=? swcnv=? pm=? -- ScanRepeat");
    cmdLine.serial().printf("\r\n 3 ch=? av=? pm=? swcnv=? -- ScanStandardInternalClock");
    cmdLine.serial().printf("\r\n 4 ch=? pm=? id=? -- ScanStandardExternalClock");
    cmdLine.serial().printf("\r\n 5 ch=? av=? pm=? swcnv=? -- ScanUpperInternalClock");
    cmdLine.serial().printf("\r\n 6 ch=? pm=? id=? -- ScanUpperExternalClock");
    cmdLine.serial().printf("\r\n 7 enableMask=? av=? pm=? swcnv=? -- ScanCustomInternalClock");
    cmdLine.serial().printf("\r\n 8 enableMask=? pm=? id=? -- ScanCustomExternalClock");
    cmdLine.serial().printf("\r\n 9 channelsPattern...=? pm=? id=? -- ScanSampleSetExternalClock");
    cmdLine.serial().printf("\r\n IB ch=? -- Reconfigure_DifferentialBipolarFSVref");
    cmdLine.serial().printf("\r\n IR ch=? -- Reconfigure_DifferentialBipolarFS2Vref");
    cmdLine.serial().printf("\r\n IS ch=? -- Reconfigure_SingleEnded");
    cmdLine.serial().printf("\r\n IU ch=? -- Reconfigure_DifferentialUnipolar");
    //
    cmdLine.serial().printf("\r\n @ -- print MAX11131 configuration");
    //
}

bool MAX11131_menu_onEOLcommandParser(CmdLine & cmdLine)
{


                    // parse argument int16_t ADC_CONFIGURATION
        int16_t ADC_CONFIGURATION = g_MAX11131_device.ADC_CONFIGURATION; // default to global property value
        if (cmdLine.parse_int16_dec("ADC_CONFIGURATION", ADC_CONFIGURATION))
        {
            g_MAX11131_device.ADC_CONFIGURATION = ADC_CONFIGURATION; // update global property value
        }

                    // parse argument int16_t ADC_MODE_CONTROL
        int16_t ADC_MODE_CONTROL = g_MAX11131_device.ADC_MODE_CONTROL; // default to global property value
        if (cmdLine.parse_int16_dec("ADC_MODE_CONTROL", ADC_MODE_CONTROL))
        {
            g_MAX11131_device.ADC_MODE_CONTROL = ADC_MODE_CONTROL; // update global property value
        }

                    // parse argument int16_t BIPOLAR
        int16_t BIPOLAR = g_MAX11131_device.BIPOLAR; // default to global property value
        if (cmdLine.parse_int16_dec("BIPOLAR", BIPOLAR))
        {
            g_MAX11131_device.BIPOLAR = BIPOLAR; // update global property value
        }

                    // parse argument int16_t CSCAN0
        int16_t CSCAN0 = g_MAX11131_device.CSCAN0; // default to global property value
        if (cmdLine.parse_int16_dec("CSCAN0", CSCAN0))
        {
            g_MAX11131_device.CSCAN0 = CSCAN0; // update global property value
        }

                    // parse argument int16_t CSCAN1
        int16_t CSCAN1 = g_MAX11131_device.CSCAN1; // default to global property value
        if (cmdLine.parse_int16_dec("CSCAN1", CSCAN1))
        {
            g_MAX11131_device.CSCAN1 = CSCAN1; // update global property value
        }

                    // parse argument uint16_t NumWords
        uint16_t NumWords = g_MAX11131_device.NumWords; // default to global property value
        if (cmdLine.parse_uint16_dec("NumWords", NumWords))
        {
            g_MAX11131_device.NumWords = NumWords; // update global property value
        }

                    // parse argument uint8_t PowerManagement_0_2
        uint8_t PowerManagement_0_2 = g_MAX11131_device.PowerManagement_0_2; // default to global property value
        if (cmdLine.parse_uint8_dec("PowerManagement_0_2", PowerManagement_0_2))
        {
            g_MAX11131_device.PowerManagement_0_2 = PowerManagement_0_2; // update global property value
        }
                    // "pm" is an alias for argument "PowerManagement_0_2"
        if (cmdLine.parse_uint8_dec("pm", PowerManagement_0_2))
        {
            g_MAX11131_device.PowerManagement_0_2 = PowerManagement_0_2; // update global property value
        }

                    // parse argument int16_t RANGE
        int16_t RANGE = g_MAX11131_device.RANGE; // default to global property value
        if (cmdLine.parse_int16_dec("RANGE", RANGE))
        {
            g_MAX11131_device.RANGE = RANGE; // update global property value
        }

                    // parse argument int16_t SAMPLESET
        int16_t SAMPLESET = g_MAX11131_device.SAMPLESET; // default to global property value
        if (cmdLine.parse_int16_dec("SAMPLESET", SAMPLESET))
        {
            g_MAX11131_device.SAMPLESET = SAMPLESET; // update global property value
        }

                    // parse argument uint8_t SPI_MOSI_Semantic
        uint8_t SPI_MOSI_Semantic = g_MAX11131_device.SPI_MOSI_Semantic; // default to global property value
        if (cmdLine.parse_uint8_dec("SPI_MOSI_Semantic", SPI_MOSI_Semantic))
        {
            g_MAX11131_device.SPI_MOSI_Semantic = SPI_MOSI_Semantic; // update global property value
        }

                    // parse argument uint8_t ScanMode
        uint8_t ScanMode = g_MAX11131_device.ScanMode; // default to global property value
        if (cmdLine.parse_uint8_dec("ScanMode", ScanMode))
        {
            g_MAX11131_device.ScanMode = ScanMode; // update global property value
        }

                    // parse argument int16_t UNIPOLAR
        int16_t UNIPOLAR = g_MAX11131_device.UNIPOLAR; // default to global property value
        if (cmdLine.parse_int16_dec("UNIPOLAR", UNIPOLAR))
        {
            g_MAX11131_device.UNIPOLAR = UNIPOLAR; // update global property value
        }

                    // parse argument double VRef
        double VRef = g_MAX11131_device.VRef; // default to global property value
        if (cmdLine.parse_double("VRef", VRef))
        {
            g_MAX11131_device.VRef = VRef; // update global property value
        }

                    // parse argument uint8_t average_0_4_8_16_32
        uint8_t average_0_4_8_16_32 = g_MAX11131_device.average_0_4_8_16_32; // default to global property value
        if (cmdLine.parse_uint8_dec("average_0_4_8_16_32", average_0_4_8_16_32))
        {
            g_MAX11131_device.average_0_4_8_16_32 = average_0_4_8_16_32; // update global property value
        }
                    // "av" is an alias for argument "average_0_4_8_16_32"
        if (cmdLine.parse_uint8_dec("av", average_0_4_8_16_32))
        {
            g_MAX11131_device.average_0_4_8_16_32 = average_0_4_8_16_32; // update global property value
        }

                    // parse argument uint8_t chan_id_0_1
        uint8_t chan_id_0_1 = g_MAX11131_device.chan_id_0_1; // default to global property value
        if (cmdLine.parse_uint8_dec("chan_id_0_1", chan_id_0_1))
        {
            g_MAX11131_device.chan_id_0_1 = chan_id_0_1; // update global property value
        }
                    // "id" is an alias for argument "chan_id_0_1"
        if (cmdLine.parse_uint8_dec("id", chan_id_0_1))
        {
            g_MAX11131_device.chan_id_0_1 = chan_id_0_1; // update global property value
        }

                    // parse argument uint8_t channelNumber_0_15
        uint8_t channelNumber_0_15 = g_MAX11131_device.channelNumber_0_15; // default to global property value
        if (cmdLine.parse_uint8_dec("channelNumber_0_15", channelNumber_0_15))
        {
            g_MAX11131_device.channelNumber_0_15 = channelNumber_0_15; // update global property value
        }
                    // "ch" is an alias for argument "channelNumber_0_15"
        if (cmdLine.parse_uint8_dec("ch", channelNumber_0_15))
        {
            g_MAX11131_device.channelNumber_0_15 = channelNumber_0_15; // update global property value
        }

                    // parse argument int16_t enabledChannelsMask
        int16_t enabledChannelsMask = g_MAX11131_device.enabledChannelsMask; // default to global property value
        if (cmdLine.parse_int16_dec("enabledChannelsMask", enabledChannelsMask))
        {
            g_MAX11131_device.enabledChannelsMask = enabledChannelsMask; // update global property value
        }
                    // "enableMask" is an alias for argument "enabledChannelsMask"
        if (cmdLine.parse_int16_dec("enableMask", enabledChannelsMask))
        {
            g_MAX11131_device.enabledChannelsMask = enabledChannelsMask; // update global property value
        }

                    // parse argument uint8_t enabledChannelsPatternLength_1_256
        uint8_t enabledChannelsPatternLength_1_256 = g_MAX11131_device.enabledChannelsPatternLength_1_256; // default to global property value
        if (cmdLine.parse_uint8_dec("enabledChannelsPatternLength_1_256", enabledChannelsPatternLength_1_256))
        {
            g_MAX11131_device.enabledChannelsPatternLength_1_256 = enabledChannelsPatternLength_1_256; // update global property value
        }

                    // parse argument uint8_t isExternalClock
        uint8_t isExternalClock = g_MAX11131_device.isExternalClock; // default to global property value
        if (cmdLine.parse_uint8_dec("isExternalClock", isExternalClock))
        {
            g_MAX11131_device.isExternalClock = isExternalClock; // update global property value
        }

                    // parse argument uint8_t nscan_4_8_12_16
        uint8_t nscan_4_8_12_16 = g_MAX11131_device.nscan_4_8_12_16; // default to global property value
        if (cmdLine.parse_uint8_dec("nscan_4_8_12_16", nscan_4_8_12_16))
        {
            g_MAX11131_device.nscan_4_8_12_16 = nscan_4_8_12_16; // update global property value
        }
                    // "n" is an alias for argument "nscan_4_8_12_16"
        if (cmdLine.parse_uint8_dec("n", nscan_4_8_12_16))
        {
            g_MAX11131_device.nscan_4_8_12_16 = nscan_4_8_12_16; // update global property value
        }

                    // parse argument uint8_t swcnv_0_1
        uint8_t swcnv_0_1 = g_MAX11131_device.swcnv_0_1; // default to global property value
        if (cmdLine.parse_uint8_dec("swcnv_0_1", swcnv_0_1))
        {
            g_MAX11131_device.swcnv_0_1 = swcnv_0_1; // update global property value
        }
                    // "swcnv" is an alias for argument "swcnv_0_1"
        if (cmdLine.parse_uint8_dec("swcnv", swcnv_0_1))
        {
            g_MAX11131_device.swcnv_0_1 = swcnv_0_1; // update global property value
        }

    switch (cmdLine[0])
    {
        case '@':
        {
                    cmdLine.serial().printf("ADC_MODE_CONTROL = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.ADC_MODE_CONTROL, g_MAX11131_device.ADC_MODE_CONTROL);
                    cmdLine.serial().printf("ADC_CONFIGURATION = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.ADC_CONFIGURATION, g_MAX11131_device.ADC_CONFIGURATION);
                    cmdLine.serial().printf("UNIPOLAR = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.UNIPOLAR, g_MAX11131_device.UNIPOLAR);
                    cmdLine.serial().printf("BIPOLAR = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.BIPOLAR, g_MAX11131_device.BIPOLAR);
                    cmdLine.serial().printf("RANGE = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.RANGE, g_MAX11131_device.RANGE);
                    cmdLine.serial().printf("CSCAN0 = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.CSCAN0, g_MAX11131_device.CSCAN0);
                    cmdLine.serial().printf("CSCAN1 = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.CSCAN1, g_MAX11131_device.CSCAN1);
                    cmdLine.serial().printf("SAMPLESET = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.SAMPLESET, g_MAX11131_device.SAMPLESET);
                    cmdLine.serial().printf("enabledChannelsPatternLength_1_256 = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.enabledChannelsPatternLength_1_256, g_MAX11131_device.enabledChannelsPatternLength_1_256);
                for(int index = 0; (index < g_MAX11131_device.enabledChannelsPatternLength_1_256) && (index < 16); index++) {
                    cmdLine.serial().printf("enabledChannelsPattern[%d] = ", index);
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.enabledChannelsPattern[index], g_MAX11131_device.enabledChannelsPattern[index]);
                }
                    cmdLine.serial().printf("SPI_MOSI_Semantic = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.SPI_MOSI_Semantic, g_MAX11131_device.SPI_MOSI_Semantic);
                    cmdLine.serial().printf("NumWords = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.NumWords, g_MAX11131_device.NumWords);
                    cmdLine.serial().printf("isExternalClock = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.isExternalClock, g_MAX11131_device.isExternalClock);
                    cmdLine.serial().printf("ScanMode = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.ScanMode, g_MAX11131_device.ScanMode);
                    cmdLine.serial().printf("channelNumber_0_15 = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.channelNumber_0_15, g_MAX11131_device.channelNumber_0_15);
                    cmdLine.serial().printf("PowerManagement_0_2 = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.PowerManagement_0_2, g_MAX11131_device.PowerManagement_0_2);
                    cmdLine.serial().printf("chan_id_0_1 = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.chan_id_0_1, g_MAX11131_device.chan_id_0_1);
                    cmdLine.serial().printf("average_0_4_8_16_32 = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.average_0_4_8_16_32, g_MAX11131_device.average_0_4_8_16_32);
                    cmdLine.serial().printf("nscan_4_8_12_16 = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.nscan_4_8_12_16, g_MAX11131_device.nscan_4_8_12_16);
                    cmdLine.serial().printf("swcnv_0_1 = ");
                    cmdLine.serial().printf("%d = 0x%2.2x\n", g_MAX11131_device.swcnv_0_1, g_MAX11131_device.swcnv_0_1);
                    cmdLine.serial().printf("enabledChannelsMask = ");
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.enabledChannelsMask, g_MAX11131_device.enabledChannelsMask);
                for(int index = 0; (index < 16) && (index < 16); index++) {
                    cmdLine.serial().printf("AINcode[%d] = ", index);
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.AINcode[index], g_MAX11131_device.AINcode[index]);
                }
                for(int index = 0; (index < 256) && (index < 16); index++) {
                    cmdLine.serial().printf("RAW_misoData16[%d] = ", index);
                    cmdLine.serial().printf("%d = 0x%4.4x\n", g_MAX11131_device.RAW_misoData16[index], g_MAX11131_device.RAW_misoData16[index]);
                }
                    cmdLine.serial().printf("VRef = ");
                    cmdLine.serial().printf("%f\n", g_MAX11131_device.VRef);
                    return true; // command handled by MAX11131
            break;
        }
        // case 'G'..'Z','g'..'z' are reserved for GPIO commands
        // case 'A'..'F','a'..'f' may be available if not claimed by bitstream commands
        case 'C':
        {
                // TODO output PulseLow
                g_MAX11131_device.CNVSToutputPulseLow();
                    return true; // command handled by MAX11131
            break;
        }
        case 'E':
        {
                // TODO capture and print input Value
                cmdLine.serial().printf(g_MAX11131_device.EOCinputValue());
                    return true; // command handled by MAX11131
            break;
        }
        // case '0'..'9','A'..'F','a'..'f' letters are reserved for bitstream commands
        case '!':
        {
                    // test menu command '!' handler:
                    // helpString='! -- Init'
                    // CMD_='None'
                    // CommandName='Init'
                    // CommandParamIn='void'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    cmdLine.serial().printf("Init");
                    // call function Init
                    g_MAX11131_device.Init();
                    return true; // command handled by MAX11131
        } // end case '!'
        break;
        case '0':
        {
                    // test menu command '0' handler:
                    // helpString='0 NumWords=? -- ReadAINcode'
                    // CMD_='SCAN_0000_NOP'
                    // CommandName='ReadAINcode'
                    // CommandParamIn='void'
                    // CommandReturnType='void'
                    // @Pre='@pre one of the Scan functions was called, setting g_MAX11131_device.NumWords'
                    // @Post='@post g_MAX11131_device.RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data,@post g_MAX11131_device.AINcode[NUM_CHANNELS] contains the latest readings in LSBs'
                    // @Return=''
                    // exception MAX11131 Menu item '0' ReadAINcode logic flow -- omit ReadAINcode call here, will be handled in postprocessing
                    cmdLine.serial().printf("ReadAINcode");
                    //
                    // CODE GENERATOR: MAX11131 ReadAINCode and print data
                    if (g_MAX11131_device.isExternalClock)
                    {
                        cmdLine.serial().print(F(" External Clock"));
                        //
                        // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                        // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                        g_MAX11131_device.ReadAINcode();
                        // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                        // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                        //
                        AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    }
                    else
                    {
                        cmdLine.serial().print(F(" Internal Clock"));
                        //
                        // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                        // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                        g_MAX11131_device.ReadAINcode();
                        // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                        // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                        //
                        AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    }
                    return true; // command handled by MAX11131
        } // end case '0'
        break;
        case '1':
        {
                    // test menu command '1' handler:
                    // helpString='1 ch=? pm=? id=? -- ScanManual'
                    // CMD_='SCAN_0001_Manual'
                    // CommandName='ScanManual'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanManual");
                    // call function ScanManual
                    int result = g_MAX11131_device.ScanManual();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanManual ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '1'
        break;
        case '2':
        {
                    // test menu command '2' handler:
                    // helpString='2 ch=? av=? n=? swcnv=? pm=? -- ScanRepeat'
                    // CMD_='SCAN_0010_Repeat'
                    // CommandName='ScanRepeat'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanRepeat");
                    // call function ScanRepeat
                    int result = g_MAX11131_device.ScanRepeat();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanRepeat ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID_mean(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '2'
        break;
        case '3':
        {
                    // test menu command '3' handler:
                    // helpString='3 ch=? av=? pm=? swcnv=? -- ScanStandardInternalClock'
                    // CMD_='SCAN_0011_StandardInternalClock'
                    // CommandName='ScanStandardInternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanStandardInternalClock");
                    // call function ScanStandardInternalClock
                    int result = g_MAX11131_device.ScanStandardInternalClock();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanStandardInternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '3'
        break;
        case '4':
        {
                    // test menu command '4' handler:
                    // helpString='4 ch=? pm=? id=? -- ScanStandardExternalClock'
                    // CMD_='SCAN_0100_StandardExternalClock'
                    // CommandName='ScanStandardExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanStandardExternalClock");
                    // call function ScanStandardExternalClock
                    int result = g_MAX11131_device.ScanStandardExternalClock();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanStandardExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '4'
        break;
        case '5':
        {
                    // test menu command '5' handler:
                    // helpString='5 ch=? av=? pm=? swcnv=? -- ScanUpperInternalClock'
                    // CMD_='SCAN_0101_UpperInternalClock'
                    // CommandName='ScanUpperInternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanUpperInternalClock");
                    // call function ScanUpperInternalClock
                    int result = g_MAX11131_device.ScanUpperInternalClock();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanUpperInternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '5'
        break;
        case '6':
        {
                    // test menu command '6' handler:
                    // helpString='6 ch=? pm=? id=? -- ScanUpperExternalClock'
                    // CMD_='SCAN_0110_UpperExternalClock'
                    // CommandName='ScanUpperExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanUpperExternalClock");
                    // call function ScanUpperExternalClock
                    int result = g_MAX11131_device.ScanUpperExternalClock();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanUpperExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '6'
        break;
        case '7':
        {
                    // test menu command '7' handler:
                    // helpString='7 enableMask=? av=? pm=? swcnv=? -- ScanCustomInternalClock'
                    // CMD_='SCAN_0111_CustomInternalClock'
                    // CommandName='ScanCustomInternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanCustomInternalClock");
                    // call function ScanCustomInternalClock
                    int result = g_MAX11131_device.ScanCustomInternalClock();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanCustomInternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_chanID(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '7'
        break;
        case '8':
        {
                    // test menu command '8' handler:
                    // helpString='8 enableMask=? pm=? id=? -- ScanCustomExternalClock'
                    // CMD_='SCAN_1000_CustomExternalClock'
                    // CommandName='ScanCustomExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre=''
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    cmdLine.serial().printf("ScanCustomExternalClock");
                    // call function ScanCustomExternalClock
                    int result = g_MAX11131_device.ScanCustomExternalClock();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanCustomExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '8'
        break;
        case '9':
        {
                    // test menu command '9' handler:
                    // helpString='9 channelsPattern...=? pm=? id=? -- ScanSampleSetExternalClock'
                    // CMD_='SCAN_1001_SampleSetExternalClock'
                    // CommandName='ScanSampleSetExternalClock'
                    // CommandParamIn='void'
                    // CommandReturnType='int'
                    // @Pre='@pre g_MAX11131_device.enabledChannelsPatternLength_1_256: number of channel selections,@pre g_MAX11131_device.enabledChannelsPattern: array containing channel selection pattern'
                    // @Post='@post NumWords = number of words to be read from the FIFO'
                    // @Return='@return number of ScanRead() words needed to retrieve the data.'
                    // exception MAX11131 Menu item '9' ScanSampleSetExternalClock
                    // parse channelsPattern using parse_byteCount_byteList_dec(size_t& byteCount, char *mosiDataBuf, size_t mosiDataBufSize)
                    size_t byteCount = g_MAX11131_device.enabledChannelsPatternLength_1_256;
                    char *mosiDataBuf = (char *)g_MAX11131_device.enabledChannelsPattern; // cast from uint8_t*
                    size_t mosiDataBufSize = sizeof(g_MAX11131_device.enabledChannelsPattern);
                    cmdLine.parse_byteCount_byteList_dec(byteCount, mosiDataBuf, mosiDataBufSize);
                    g_MAX11131_device.enabledChannelsPatternLength_1_256 = byteCount;
                    cmdLine.serial().printf("ScanSampleSetExternalClock");
                    // call function ScanSampleSetExternalClock
                    int result = g_MAX11131_device.ScanSampleSetExternalClock();
                    cmdLine.serial().printf(" =%d", result);
                    //
                    // CODE GENERATOR: MAX11131 post-ScanSampleSetExternalClock ReadAINCode and print data
                    // Read raw ADC codes from device into AINcode[] and RAW_misoData16[]
                    // @pre one of the MAX11311_Scan functions was called, setting g_MAX11131_device.NumWords
                    g_MAX11131_device.ReadAINcode();
                    // @post RAW_misoData16[index] contains the raw SPI Master-In,Slave-Out data
                    // @post AINcode[NUM_CHANNELS] contains the latest readings in LSBs
                    //
                    AINcode_print_value_externalClock(cmdLine, g_MAX11131_device.NumWords);
                    return true; // command handled by MAX11131
        } // end case '9'
        break;
        case 'I':
        {
            switch (cmdLine[1])
            {
                case 'B':
                {
                    // test menu command 'IB' handler:
                    // helpString='IB ch=? -- Reconfigure_DifferentialBipolarFSVref'
                    // CMD_='None'
                    // CommandName='Reconfigure_DifferentialBipolarFSVref'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().printf("Reconfigure_DifferentialBipolarFSVref");
                    cmdLine.serial().printf(" channel_0_15=%d", channel_0_15);
                    cmdLine.serial().printf("\r\n");
                    // call function Reconfigure_DifferentialBipolarFSVref(channel_0_15)
                    g_MAX11131_device.Reconfigure_DifferentialBipolarFSVref(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IB'
                break;
                case 'R':
                {
                    // test menu command 'IR' handler:
                    // helpString='IR ch=? -- Reconfigure_DifferentialBipolarFS2Vref'
                    // CMD_='None'
                    // CommandName='Reconfigure_DifferentialBipolarFS2Vref'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().printf("Reconfigure_DifferentialBipolarFS2Vref");
                    cmdLine.serial().printf(" channel_0_15=%d", channel_0_15);
                    cmdLine.serial().printf("\r\n");
                    // call function Reconfigure_DifferentialBipolarFS2Vref(channel_0_15)
                    g_MAX11131_device.Reconfigure_DifferentialBipolarFS2Vref(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IR'
                break;
                case 'S':
                {
                    // test menu command 'IS' handler:
                    // helpString='IS ch=? -- Reconfigure_SingleEnded'
                    // CMD_='None'
                    // CommandName='Reconfigure_SingleEnded'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().printf("Reconfigure_SingleEnded");
                    cmdLine.serial().printf(" channel_0_15=%d", channel_0_15);
                    cmdLine.serial().printf("\r\n");
                    // call function Reconfigure_SingleEnded(channel_0_15)
                    g_MAX11131_device.Reconfigure_SingleEnded(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IS'
                break;
                case 'U':
                {
                    // test menu command 'IU' handler:
                    // helpString='IU ch=? -- Reconfigure_DifferentialUnipolar'
                    // CMD_='None'
                    // CommandName='Reconfigure_DifferentialUnipolar'
                    // CommandParamIn='int channel_0_15'
                    // CommandReturnType='void'
                    // @Pre=''
                    // @Post=''
                    // @Return=''
                    // parse argument list
                    // parse argument int channel_0_15
                    int channel_0_15 = 0; // --- g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__; // default to global property value
                    if (cmdLine.parse_int16_dec("channel_0_15", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // "ch" is an alias for argument "channel_0_15"
                    if (cmdLine.parse_int16_dec("ch", channel_0_15))
                    {
                        // g_MAX11131_device.__WARNING_no_match_for_argname_channel_0_15_in_MAX11131_device_t__ = channel_0_15; // update global property value
                    }
                    // print arguments
                    cmdLine.serial().printf("Reconfigure_DifferentialUnipolar");
                    cmdLine.serial().printf(" channel_0_15=%d", channel_0_15);
                    cmdLine.serial().printf("\r\n");
                    // call function Reconfigure_DifferentialUnipolar(channel_0_15)
                    g_MAX11131_device.Reconfigure_DifferentialUnipolar(channel_0_15);
                    return true; // command handled by MAX11131
                } // end nested case 'IU'
                break;
            } // end nested switch (cmdLine[1])
            break;
        } // end case 'I'
    } // end switch (cmdLine[0])
    return false; // command not handled by MAX11131
} // end bool MAX11131_menu_onEOLcommandParser(CmdLine & cmdLine)

